--
-- PostgreSQL database dump
--

\restrict cIv5xNCN32K76yFCWqrAQHwa70xfOBa2HtJ1ZIAquL9waN1R8nvZDWEdgcTguWp

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.account_status AS ENUM (
    'pending',
    'verified',
    'suspended'
);


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'guest',
    'locksmith',
    'super_admin'
);


--
-- Name: actor_fingerprint(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.actor_fingerprint() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                        DECLARE
                                                                                                                                          v_uid    UUID;
                                                                                                                                            v_ip     TEXT;
                                                                                                                                              v_pepper TEXT;
                                                                                                                                              BEGIN
                                                                                                                                                v_uid := (SELECT auth.uid());
                                                                                                                                                  IF v_uid IS NOT NULL THEN
                                                                                                                                                      RETURN 'u:' || v_uid::text;
                                                                                                                                                        END IF;

                                                                                                                                                          BEGIN
                                                                                                                                                              v_ip := current_setting('request.headers', true)::json ->> 'x-forwarded-for';
                                                                                                                                                                EXCEPTION WHEN OTHERS THEN
                                                                                                                                                                    v_ip := NULL;
                                                                                                                                                                      END;

                                                                                                                                                                        BEGIN
                                                                                                                                                                            v_pepper := public.get_pepper('autokey_fingerprint_pepper');
                                                                                                                                                                              EXCEPTION WHEN OTHERS THEN
                                                                                                                                                                                  v_pepper := 'fallback-rate-limit-salt';
                                                                                                                                                                                    END;

                                                                                                                                                                                      RETURN 'a:' || encode(
                                                                                                                                                                                          sha256(convert_to(v_pepper || ':' || coalesce(v_ip, 'unknown') || ':' || v_pepper, 'UTF8')),
                                                                                                                                                                                              'hex'
                                                                                                                                                                                                );
                                                                                                                                                                                                END;
                                                                                                                                                                                                $$;


--
-- Name: admin_list_technicians(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_list_technicians() RETURNS TABLE(user_id uuid, email text, display_name text, workshop_name text, city text, role text, status text, has_license boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                           BEGIN
                                                                                             IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                 RAISE EXCEPTION 'غير مصرّح: يتطلب حساب مدير مع تحقق ثنائي مفعّل.'
                                                                                                       USING ERRCODE = 'insufficient_privilege';
                                                                                                         END IF;

                                                                                                           RETURN QUERY
                                                                                                             SELECT
                                                                                                                 p.id,
                                                                                                                     u.email::text,
                                                                                                                         p.display_name::text,
                                                                                                                             p.workshop_name::text,
                                                                                                                                 p.city::text,
                                                                                                                                     p.role::text,
                                                                                                                                         p.status::text,
                                                                                                                                             (p.license_ref_hash IS NOT NULL),
                                                                                                                                                 p.created_at
                                                                                                                                                   FROM public.profiles p
                                                                                                                                                     JOIN auth.users u ON u.id = p.id
                                                                                                                                                       ORDER BY
                                                                                                                                                           (p.status = 'pending'::public.account_status) DESC,   -- المعلّقة أولاً
                                                                                                                                                               p.created_at DESC;
                                                                                                                                                               END;
                                                                                                                                                               $$;


--
-- Name: admin_set_technician_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_set_technician_status(p_user_id uuid, p_status text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                   BEGIN
                                                                                                                                                                     IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                         RAISE EXCEPTION 'غير مصرّح: يتطلب حساب مدير مع تحقق ثنائي مفعّل.'
                                                                                                                                                                               USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                 END IF;

                                                                                                                                                                                   IF p_status NOT IN ('pending','verified','suspended') THEN
                                                                                                                                                                                       RAISE EXCEPTION 'حالة غير صحيحة: %', p_status
                                                                                                                                                                                             USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                               END IF;

                                                                                                                                                                                                 -- حماية: لا يستطيع المدير إيقاف نفسه فيُغلق النظام على الجميع
                                                                                                                                                                                                   IF p_user_id = (SELECT auth.uid()) THEN
                                                                                                                                                                                                       RAISE EXCEPTION 'لا يمكنك تغيير حالة حسابك بنفسك.'
                                                                                                                                                                                                             USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                               END IF;

                                                                                                                                                                                                                 -- التعديل يمر عبر مُشغّل منع التصعيد ومُشغّل التدقيق تلقائياً
                                                                                                                                                                                                                   UPDATE public.profiles
                                                                                                                                                                                                                     SET status = p_status::public.account_status
                                                                                                                                                                                                                       WHERE id = p_user_id;

                                                                                                                                                                                                                         IF NOT FOUND THEN
                                                                                                                                                                                                                             RAISE EXCEPTION 'لم يُعثر على الحساب.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                               END IF;
                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                               $$;


--
-- Name: cleanup_rate_limit_events(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_rate_limit_events() RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DELETE FROM public.rate_limit_events WHERE created_at < now() - INTERVAL '1 day';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       $$;


--
-- Name: enforce_rate_limit(text, integer, interval); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_rate_limit(p_action text, p_limit integer, p_window interval) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                         DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                           v_actor TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                             v_count INT;
                                                                                                                                                                                                                                                                                                                                                                                                                                             BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                               v_actor := public.actor_fingerprint();

                                                                                                                                                                                                                                                                                                                                                                                                                                                 SELECT count(*) INTO v_count
                                                                                                                                                                                                                                                                                                                                                                                                                                                   FROM public.rate_limit_events e
                                                                                                                                                                                                                                                                                                                                                                                                                                                     WHERE e.actor_key = v_actor
                                                                                                                                                                                                                                                                                                                                                                                                                                                         AND e.action    = p_action
                                                                                                                                                                                                                                                                                                                                                                                                                                                             AND e.created_at > now() - p_window;

                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF v_count >= p_limit THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RAISE EXCEPTION
                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'تم تجاوز الحد المسموح من الطلبات. حاول مرة أخرى بعد قليل.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               USING ERRCODE = 'too_many_connections';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   INSERT INTO public.rate_limit_events (actor_key, action)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     VALUES (v_actor, p_action);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     $$;


--
-- Name: get_pepper(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_pepper(p_name text) RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                        DECLARE
                                                                                          v_secret TEXT;
                                                                                          BEGIN
                                                                                            SELECT s.decrypted_secret INTO v_secret
                                                                                              FROM vault.decrypted_secrets s
                                                                                                WHERE s.name = p_name;

                                                                                                  IF v_secret IS NULL OR length(v_secret) < 32 THEN
                                                                                                      RAISE EXCEPTION 'الملح الأمني غير مضبوط. نفّذ ملف set_pepper_vault.sql أولاً.'
                                                                                                            USING ERRCODE = 'config_file_error';
                                                                                                              END IF;

                                                                                                                RETURN v_secret;
                                                                                                                END;
                                                                                                                $$;


--
-- Name: guard_profile_privileges(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_profile_privileges() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                    BEGIN
                                                                                                                                                                                                                                                                                      -- المدير المتحقق بـ 2FA فقط يملك تغيير الدور أو الحالة أو القفل
                                                                                                                                                                                                                                                                                        IF (NEW.role IS DISTINCT FROM OLD.role)
                                                                                                                                                                                                                                                                                             OR (NEW.status IS DISTINCT FROM OLD.status)
                                                                                                                                                                                                                                                                                                  OR (NEW.locked_until IS DISTINCT FROM OLD.locked_until)
                                                                                                                                                                                                                                                                                                       OR (NEW.mfa_required IS DISTINCT FROM OLD.mfa_required)
                                                                                                                                                                                                                                                                                                         THEN
                                                                                                                                                                                                                                                                                                             IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                   RAISE EXCEPTION
                                                                                                                                                                                                                                                                                                                           'غير مسموح بتغيير الصلاحيات. يتطلب حساب مدير مع تحقق ثنائي مفعّل.'
                                                                                                                                                                                                                                                                                                                                   USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                       END IF;
                                                                                                                                                                                                                                                                                                                                         END IF;

                                                                                                                                                                                                                                                                                                                                           RETURN NEW;
                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE
  v_meta    JSONB;
    v_license TEXT;
      v_pepper  TEXT;
      BEGIN
        v_meta    := coalesce(NEW.raw_user_meta_data, '{}'::jsonb);
          v_license := nullif(btrim(coalesce(v_meta ->> 'license_ref','')), '');
            v_pepper  := coalesce(current_setting('app.vin_pepper', true), 'autokey-default-pepper');

              INSERT INTO public.profiles (
                  id, role, status, display_name, workshop_name, city, license_ref_hash
                    )
                      VALUES (
                          NEW.id,
                              'locksmith'::public.app_role,        -- ثابت
                                  'pending'::public.account_status,    -- ثابت — لا وصول حتى الاعتماد
                                      nullif(btrim(coalesce(v_meta ->> 'display_name','')), ''),
                                          nullif(btrim(coalesce(v_meta ->> 'workshop_name','')), ''),
                                              nullif(btrim(coalesce(v_meta ->> 'city','')), ''),
                                                  CASE WHEN v_license IS NULL THEN NULL
                                                           ELSE encode(sha256(convert_to(v_pepper || ':' || v_license || ':' || v_pepper, 'UTF8')), 'hex')
                                                               END
                                                                 )
                                                                   ON CONFLICT (id) DO NOTHING;   -- يحمي الحسابات الموجودة مسبقاً

                                                                     RETURN NEW;
                                                                     END;
                                                                     $$;


--
-- Name: has_mfa(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_mfa() RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                        SELECT coalesce((SELECT auth.jwt() ->> 'aal'), 'aal1') = 'aal2';
                                                                                                                                                                                                                                                        $$;


--
-- Name: is_super_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_super_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                            SELECT EXISTS (
                                                                                                                                                                                                SELECT 1 FROM public.profiles p
                                                                                                                                                                                                    WHERE p.id = (SELECT auth.uid())
                                                                                                                                                                                                          AND p.role   = 'super_admin'::public.app_role
                                                                                                                                                                                                                AND p.status = 'verified'::public.account_status
                                                                                                                                                                                                                      AND (p.locked_until IS NULL OR p.locked_until < now())
                                                                                                                                                                                                                        );
                                                                                                                                                                                                                        $$;


--
-- Name: is_verified_locksmith(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_verified_locksmith() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                          SELECT EXISTS (
                                                                                                                                                                                                                              SELECT 1 FROM public.profiles p
                                                                                                                                                                                                                                  WHERE p.id = (SELECT auth.uid())
                                                                                                                                                                                                                                        AND p.role IN ('locksmith'::public.app_role, 'super_admin'::public.app_role)
                                                                                                                                                                                                                                              AND p.status = 'verified'::public.account_status
                                                                                                                                                                                                                                                    AND (p.locked_until IS NULL OR p.locked_until < now())
                                                                                                                                                                                                                                                      );
                                                                                                                                                                                                                                                      $$;


--
-- Name: list_lishi_tools(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_lishi_tools() RETURNS TABLE(tool_name text, blade_code text, supported_cars text, cut_positions text, pick_direction text, notes text, is_full_access boolean)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                            DECLARE
                                              v_full BOOLEAN;
                                              BEGIN
                                                v_full := public.is_verified_locksmith();

                                                  RETURN QUERY
                                                    SELECT
                                                        t.tool_name::text,
                                                            t.blade_code::text,
                                                                t.supported_cars::text,
                                                                    CASE WHEN v_full THEN t.cut_positions::text  ELSE NULL END,
                                                                        CASE WHEN v_full THEN t.pick_direction::text ELSE NULL END,
                                                                            CASE WHEN v_full THEN t.notes::text          ELSE NULL END,
                                                                                v_full
                                                                                  FROM public.lishi_tools t
                                                                                    ORDER BY t.tool_name;
                                                                                    END;
                                                                                    $$;


--
-- Name: list_makes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_makes() RETURNS TABLE(make text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
  SELECT DISTINCT c.make::text
    FROM public.cars_key_data c
      WHERE c.make IS NOT NULL AND btrim(c.make) <> ''
        ORDER BY 1;
        $$;


--
-- Name: list_models(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_models(p_make text) RETURNS TABLE(model text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
          SELECT DISTINCT c.model::text
            FROM public.cars_key_data c
              WHERE c.make = p_make
                  AND c.model IS NOT NULL AND btrim(c.model) <> ''
                    ORDER BY 1;
                    $$;


--
-- Name: list_years(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_years(p_make text, p_model text) RETURNS TABLE(year integer)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                      SELECT DISTINCT gs::int
                        FROM public.cars_key_data c
                          CROSS JOIN LATERAL generate_series(c.year_from::int, c.year_to::int) AS gs
                            WHERE c.make = p_make AND c.model = p_model
                              ORDER BY 1;
                              $$;


--
-- Name: my_access_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_access_status() RETURNS TABLE(role text, status text, display_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                 SELECT p.role::text, p.status::text, p.display_name::text
                                                                                                                                                                                                                                   FROM public.profiles p
                                                                                                                                                                                                                                     WHERE p.id = (SELECT auth.uid());
                                                                                                                                                                                                                                     $$;


--
-- Name: record_audit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_audit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             v_record_id TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF TG_OP = 'DELETE' THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   v_record_id := (to_jsonb(OLD) ->> 'id');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       INSERT INTO public.audit_log (actor_id, action, table_name, record_id, old_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           VALUES ((SELECT auth.uid()), TG_OP, TG_TABLE_NAME, v_record_id, to_jsonb(OLD));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RETURN OLD;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ELSE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     v_record_id := (to_jsonb(NEW) ->> 'id');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         INSERT INTO public.audit_log (actor_id, action, table_name, record_id, old_data, new_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             VALUES (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   (SELECT auth.uid()),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         TG_OP,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               TG_TABLE_NAME,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     v_record_id,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 to_jsonb(NEW)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RETURN NEW;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: search_cars(text, text, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_cars(p_make text, p_model text DEFAULT NULL::text, p_year integer DEFAULT NULL::integer, p_key_type text DEFAULT NULL::text, p_market text DEFAULT NULL::text) RETURNS TABLE(id text, make text, model text, year_from integer, year_to integer, market text, key_type text, transponder_type text, remote_frequency text, fcc_id text, programming_type text, key_blade text, programming_details text, eeprom_location text, oem_part_number text, special_requirements text, execution_steps text, warnings_notes text, board_image_url text, is_full_access boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             v_full BOOLEAN;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               -- معيار بحث إلزامي: يمنع سحب القاعدة كاملة
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 IF p_make IS NULL OR length(btrim(p_make)) < 2 THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     RAISE EXCEPTION 'يجب تحديد الماركة للبحث (حرفان على الأقل).'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               v_full := public.is_verified_locksmith();

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 -- حد أعلى للزائر، وحد أوسع للفني الموثّق
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   IF v_full THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       PERFORM public.enforce_rate_limit('search_cars', 300, INTERVAL '5 minutes');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ELSE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             PERFORM public.enforce_rate_limit('search_cars', 40, INTERVAL '5 minutes');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 -- كل عمود مُحوّل صراحةً (::text / ::int) حتى تعمل الدالة بغض النظر
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   -- عن كون الأعمدة varchar أو text، و int4 أو int8 في جدولك.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SELECT
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           c.id::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               c.make::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   c.model::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       c.year_from::int,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           c.year_to::int,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               c.market::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   c.key_type::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       c.transponder_type::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           c.remote_frequency::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               c.fcc_id::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   c.programming_type::text,

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       CASE WHEN v_full THEN c.key_blade::text            ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           CASE WHEN v_full THEN c.programming_details::text  ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               CASE WHEN v_full THEN c.eeprom_location::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   CASE WHEN v_full THEN c.oem_part_number::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       CASE WHEN v_full THEN c.special_requirements::text ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           CASE WHEN v_full THEN c.execution_steps::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               CASE WHEN v_full THEN c.warnings_notes::text       ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   CASE WHEN v_full THEN c.board_image_url::text      ELSE NULL END,

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       v_full
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           WHERE c.make ILIKE '%' || btrim(p_make) || '%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               AND (p_model    IS NULL OR c.model ILIKE '%' || btrim(p_model) || '%')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   AND (p_year     IS NULL OR (p_year >= c.year_from AND p_year <= c.year_to))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       AND (p_key_type IS NULL OR p_key_type = '' OR c.key_type = p_key_type)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           AND (p_market   IS NULL OR p_market   = '' OR c.market   = p_market)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ORDER BY c.make, c.model, c.year_from DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               LIMIT 100;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               $$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
                                                                                                                                                                                  BEGIN
                                                                                                                                                                                    NEW.updated_at = now();
                                                                                                                                                                                      RETURN NEW;
                                                                                                                                                                                      END;
                                                                                                                                                                                      $$;


--
-- Name: vin_fingerprint(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vin_fingerprint(p_vin text) RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                DECLARE
                                                                                                                  v_pepper TEXT;
                                                                                                                  BEGIN
                                                                                                                    IF p_vin IS NULL OR length(btrim(p_vin)) = 0 THEN
                                                                                                                        RETURN NULL;
                                                                                                                          END IF;

                                                                                                                            v_pepper := public.get_pepper('autokey_vin_pepper');

                                                                                                                              RETURN encode(
                                                                                                                                  sha256(convert_to(v_pepper || ':' || upper(btrim(p_vin)) || ':' || v_pepper, 'UTF8')),
                                                                                                                                      'hex'
                                                                                                                                        );
                                                                                                                                        END;
                                                                                                                                        $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor_id uuid,
    action text NOT NULL,
    table_name text NOT NULL,
    record_id text,
    old_data jsonb,
    new_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cars_key_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cars_key_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year_from integer NOT NULL,
    year_to integer NOT NULL,
    market text DEFAULT 'gcc'::text,
    transponder_type text,
    key_blade text,
    remote_frequency text,
    programming_type text,
    programming_details text,
    eeprom_location text,
    image_url text,
    board_image_url text,
    fcc_id text,
    key_type text,
    oem_part_number text,
    special_requirements text,
    execution_steps text,
    warnings_notes text,
    CONSTRAINT cars_key_data_key_type_check CHECK (((key_type IS NULL) OR (key_type = ANY (ARRAY['smart'::text, 'remote'::text, 'blade'::text]))))
);


--
-- Name: COLUMN cars_key_data.key_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cars_key_data.key_type IS 'نوع المفتاح: smart = بصمة، remote = مفتاح بريموت، blade = مفتاح عادي';


--
-- Name: lishi_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lishi_tools (
    id bigint NOT NULL,
    tool_name text NOT NULL,
    blade_code text NOT NULL,
    supported_cars text NOT NULL,
    cut_positions text,
    pick_direction text,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: lishi_tools_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.lishi_tools ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lishi_tools_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    role public.app_role DEFAULT 'guest'::public.app_role NOT NULL,
    status public.account_status DEFAULT 'pending'::public.account_status NOT NULL,
    display_name text,
    workshop_name text,
    city text,
    license_ref_hash text,
    mfa_required boolean DEFAULT false NOT NULL,
    locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.profiles IS 'ملفات الفنيين والصلاحيات. كلمات المرور في auth.users (bcrypt عبر Supabase Auth)';


--
-- Name: COLUMN profiles.license_ref_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.license_ref_hash IS 'بصمة مشفّرة لرقم الرخصة — لا يُخزَّن الرقم الصريح أبداً';


--
-- Name: rate_limit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_events (
    id bigint NOT NULL,
    actor_key text NOT NULL,
    action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rate_limit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rate_limit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: work_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    technician_id uuid NOT NULL,
    car_ref text,
    job_type text,
    vin_fingerprint text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT work_log_vin_fingerprint_check CHECK (((vin_fingerprint IS NULL) OR (vin_fingerprint ~ '^[0-9a-f]{64}$'::text)))
);


--
-- Name: TABLE work_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_log IS 'سجل أعمال الفني — بدون لوحات وبدون VIN صريح، لمنع تتبّع تحركات الفنيين';


--
-- Name: COLUMN work_log.vin_fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_log.vin_fingerprint IS 'بصمة HMAC-SHA256 للـ VIN — لا يمكن عكسها لاستخراج الرقم الأصلي';


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, actor_id, action, table_name, record_id, old_data, new_data, created_at) FROM stdin;
1	\N	INSERT	profiles	796b0d23-5e2b-4a05-a18d-311eb39c6c11	\N	{"id": "796b0d23-5e2b-4a05-a18d-311eb39c6c11", "city": null, "role": "super_admin", "status": "verified", "created_at": "2026-09-02T23:51:39.757992+00:00", "updated_at": "2026-09-02T23:51:39.757992+00:00", "display_name": null, "locked_until": null, "mfa_required": true, "workshop_name": null, "license_ref_hash": null}	2026-09-02 23:51:39.757992+00
2	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	73075312-877b-4b6d-bcaf-7b3ddd358350	{"id": "73075312-877b-4b6d-bcaf-7b3ddd358350", "make": "تويوتا", "model": "كامري", "fcc_id": null, "market": "gcc", "year_to": 2002, "key_type": null, "image_url": null, "key_blade": "لِيشي: TOY43", "year_from": 2001, "created_at": "2026-08-31T08:34:02.653922+00:00", "warnings_notes": null, "board_image_url": null, "eeprom_location": "جهاز ايمو خلف المسجل", "execution_steps": null, "oem_part_number": null, "programming_type": "manual", "remote_frequency": "", "transponder_type": "ID 4C/000000", "programming_details": "تحول شريحه اصفار", "special_requirements": null}	{"id": "73075312-877b-4b6d-bcaf-7b3ddd358350", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2002, "key_type": null, "image_url": null, "key_blade": "لِيشي: TOY43", "year_from": 2001, "created_at": "2026-08-31T08:34:02.653922+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "جهاز ايمو خلف المسجل", "execution_steps": "", "oem_part_number": "", "programming_type": "manual", "remote_frequency": "", "transponder_type": "ID 4C/000000", "programming_details": "تحول شريحه اصفار", "special_requirements": ""}	2026-09-03 00:08:22.964034+00
3	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	fce6f926-aff3-4cbc-a388-c095e5b4c283	{"id": "fce6f926-aff3-4cbc-a388-c095e5b4c283", "make": "نيسان", "model": "ألتيما (Altima)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "NSN14 / لِيشي: Lishi NSN14", "year_from": 2019, "created_at": "2026-09-02T22:26:01.958576+00:00", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC Specs)", "transponder_type": "Hitag AES (ID4A / NCF29A1M)", "programming_details": "عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR", "special_requirements": null}	{"id": "fce6f926-aff3-4cbc-a388-c095e5b4c283", "make": "نيسان", "model": "ألتيما (Altima)", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": "smart", "image_url": null, "key_blade": "NSN14 / لِيشي: Lishi NSN14", "year_from": 2019, "created_at": "2026-09-02T22:26:01.958576+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC Specs)", "transponder_type": "Hitag AES (ID4A / NCF29A1M)", "programming_details": "عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR", "special_requirements": ""}	2026-09-03 00:09:20.753057+00
4	796b0d23-5e2b-4a05-a18d-311eb39c6c11	INSERT	cars_key_data	189f9aca-5bd5-4d27-8618-5e4428682eeb	\N	{"id": "189f9aca-5bd5-4d27-8618-5e4428682eeb", "make": "هيونداي", "model": "اكسنت", "fcc_id": "", "market": "gcc", "year_to": 2006, "key_type": "blade", "image_url": null, "key_blade": "", "year_from": 2001, "created_at": "2026-09-03T00:15:00.587947+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "manual", "remote_frequency": "", "transponder_type": "46", "programming_details": "", "special_requirements": ""}	2026-09-03 00:15:00.587947+00
\.


--
-- Data for Name: cars_key_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cars_key_data (id, created_at, make, model, year_from, year_to, market, transponder_type, key_blade, remote_frequency, programming_type, programming_details, eeprom_location, image_url, board_image_url, fcc_id, key_type, oem_part_number, special_requirements, execution_steps, warnings_notes) FROM stdin;
189f9aca-5bd5-4d27-8618-5e4428682eeb	2026-09-03 00:15:00.587947+00	هيونداي	اكسنت	2001	2006	gcc	46			manual			\N	\N		blade				
f6a25fc0-ce56-4562-9c43-ab5fa0b6dce8	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2003	2006	gcc	4C	لِيشي: TOY43		obd	OBD مطلوب لمعظم الحالات (Smart Pro / AutoProPad / Tango)	داخل كمبيوتر المحرك (ECU) — يُقرأ عبر جهاز متخصص عند فقد جميع المفاتيح	\N	\N	\N	\N	\N	\N	\N	\N
8b9a737a-2699-45b7-a577-36ef951518b4	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2007	2012	gcc	Toyota 4D-67-Chip	لِيشي:  TOY43		obd	OBD إلزامي — Smart Pro / AutoProPad		\N	\N	\N	\N	\N	\N	\N	\N
73075312-877b-4b6d-bcaf-7b3ddd358350	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2001	2002	gcc	ID 4C/000000	لِيشي: TOY43		manual	تحول شريحه اصفار	جهاز ايمو خلف المسجل	\N	\N		\N				
12d44165-a6ee-40a5-bc02-a7e42a77c419	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2018	2024	us	Toyota H-Chip / Smart Key (AES)	مفتاح ذكي بدون شفرة تقليدية (Emergency Key: TOY44D)	315 MHz	obd	OBD + تصريح أونلاين من تويوتا (Toyota FTZ / TIS Techstream) في أغلب الحالات	Smart Key ECU خلف لوحة القيادة اليمنى	\N	\N	\N	smart	\N	\N	\N	\N
95973140-8f4c-4eb3-aadf-8215f71edd37	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2007	2011	us	Toyota G-Chip (128-bit)	TOY44 / لِيشي: TOY44	315 MHz	obd	OBD إلزامي (لا توجد طريقة يدوية) — Smart Pro / AutoProPad	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
3b6b69e6-6249-4126-902c-0454a319edfb	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2006	2015	gcc	بدون	TOY43 / لِيشي: TOY43		manual			\N	\N	\N	\N	\N	\N	\N	\N
57c931ea-3017-413d-a63e-c2de535d370b	2026-08-31 09:22:07.170698+00	تويوتا	كورولا	2001	2006	gcc	4C	toy43		manual	فك كمبيوتر	25020	\N	\N	\N	\N	\N	\N	\N	\N
5e4581bf-55bb-414e-99eb-34a511325a08	2026-09-01 13:03:43.657206+00	تويوتا	افلون	0	25	gcc				manual			\N	\N	\N	\N	\N	\N	\N	\N
207bd0d6-44ec-4efa-92da-78020f9d509d	2026-09-01 13:04:11.952317+00	تويوتا	اوريون	0	1	gcc				manual			\N	\N	\N	\N	\N	\N	\N	\N
d268362a-d9c2-44ec-9a7f-dab963fabe5a	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	1999	2005	us	ID46 (PCF7936)	HY15 / لِيشي: HU134	315 MHz	manual	عبر Pin Code محسوب من رقم الهيكل (VIN)	غير مطلوب غالباً — يعتمد على Pin Code وليس EEPROM	\N	\N	\N	remote	\N	\N	\N	\N
189ce114-0332-406e-9c21-96a85678955f	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2018	2024	gcc	Toyota H-Chip / Smart Key (AES)	مفتاح ذكي بدون شفرة تقليدية (Emergency Key: TOY44D)	433 MHz	obd	OBD + تصريح أونلاين من تويوتا في أغلب الحالات	Smart Key ECU خلف لوحة القيادة اليمنى	\N	\N	\N	smart	\N	\N	\N	\N
8e9162fd-7cde-444b-b38c-764e74f2d192	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2000	2001	us	Toyota 4D-67 (TP08)	TR47 / لِيشي: TOY43	315 MHz	manual	يدوية بمفتاحين سليمين (10 دورات تشغيل/إيقاف) أو عبر جهاز OBD	غير مطلوب عادة — عند فقد كل المفاتيح: قراءة كمبيوتر المحرك عبر جهاز متخصص (Tango/MVP)	\N	\N	\N	remote	\N	\N	\N	\N
96b6bfb2-c829-45b1-93cf-05fbe4451ef2	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2002	2006	us	Toyota 4D-67	TR47 / لِيشي: TOY43	315 MHz	obd	OBD مطلوب لمعظم الحالات (Smart Pro / AutoProPad / Tango)	داخل كمبيوتر المحرك (ECU) — يُقرأ عبر جهاز متخصص عند فقد جميع المفاتيح	\N	\N	\N	remote	\N	\N	\N	\N
ed4584c3-d5b8-42f2-b1f7-ad25a18430cd	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2012	2017	us	Toyota H-Chip (128-bit AES)	TOY44D — بعض الفئات مفتاح ذكي بدون شفرة	315 MHz	obd	OBD إلزامي، ومفاتيح النظام الذكي تحتاج غالباً اتصال أونلاين بسيرفر تويوتا	BCM / Smart Key ECU — خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
cd962bb2-1955-455e-8085-cb63900ec15a	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2013	2015	gcc	Toyota G-Chip	TOY43	433 MHz	obd	OBD إلزامي، نظام المفتاح الذكي	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N
309d3433-9ca6-477d-9276-bc0e755b244a	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	1999	2005	gcc	ID46 (PCF7936)	HY15 / لِيشي: HU134	433 MHz	manual	عبر Pin Code محسوب من رقم الهيكل (VIN)	غير مطلوب غالباً — يعتمد على Pin Code	\N	\N	\N	remote	\N	\N	\N	\N
c96ef0ea-ac0f-47d5-bfc6-7cbf4db132c0	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2006	2010	us	ID46 (PCF7936/7961)	HY15 / لِيشي: HU134	315 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD (Smart Pro / AutoProPad)	BCM — يُفك عند فقد Pin Code وعدم توفر جهاز OBD	\N	\N	\N	remote	\N	\N	\N	\N
861a3aa3-70b5-49cc-a2af-8987516eb3d2	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2006	2010	gcc	ID46 (PCF7936/7961)	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM	\N	\N	\N	remote	\N	\N	\N	\N
a2c6b7c6-1087-46d5-a5e3-b7e6b0bfc6e2	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2011	2014	us	ID46 / Hitag2	HY15 — بعض الفئات مفتاح ذكي (SUV/عليا)	315 MHz	obd	OBD إلزامي غالباً (Pin Code يُقرأ عبر الجهاز مباشرة من BCM)	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
ce6f8a5b-6ab9-4820-9be8-f9205416dd11	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2011	2014	gcc	ID46 / Hitag2	HY15 — بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
2502d3be-ea4d-4a67-9ef6-708cd92bd316	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2015	2019	us	Hitag2 / ID46 — مفتاح ذكي شائع	HY22 (Emergency) / لِيشي: HU134	315 MHz	obd	OBD إلزامي، بعض الفئات تحتاج تصريح أونلاين من هيونداي	Smart Key Unit + BCM	\N	\N	\N	remote	\N	\N	\N	\N
5c00e561-e2f9-484e-9e93-2184ace743d0	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2015	2019	gcc	Hitag2 / ID46 — مفتاح ذكي شائع	HY22 (Emergency)	433 MHz	obd	OBD إلزامي، بعض الفئات تحتاج تصريح أونلاين	Smart Key Unit + BCM	\N	\N	\N	remote	\N	\N	\N	\N
87b73b2b-d3fb-4f95-a12d-ebd6552bce3b	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2020	2024	us	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي (إلزامي تقريباً)	Smart Key Unit — الوصول المباشر نادراً ما يكون متاحاً	\N	\N	\N	remote	\N	\N	\N	\N
7735e5c0-a5c5-4d76-8d3b-2ec0c4609ace	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2020	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
695349e0-7c16-49d7-b9e5-43deec100e1b	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	1998	2002	us	Texas Instruments 4C (PATS 1)	H75 / لِيشي: FO21	315 MHz	manual	يدوية بالكامل عبر دورة PATS القياسية بدون أي جهاز	غير مطلوب — النظام PATS 1 لا يحتاج EEPROM في الحالات العادية	\N	\N	\N	remote	\N	\N	\N	\N
ed75863c-a3d4-4ee4-98be-3ac8656175e5	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	1998	2002	gcc	Texas Instruments 4C (PATS 1)	H75 / لِيشي: FO21	315 MHz (وحدات مستوردة أمريكية غالباً)	manual	يدوية بالكامل عبر دورة PATS القياسية	غير مطلوب في الحالات العادية	\N	\N	\N	remote	\N	\N	\N	\N
e0920eaa-1714-497a-a542-20d051014b14	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2003	2007	us	Texas Instruments 4D-63 (PATS 3)	H84 / لِيشي: FO21	315 MHz	obd	يدوية إذا توفر مفتاحان سليمان، أو OBD (Incode/Outcode) عند فقد كل المفاتيح	وحدة PATS خلف الكلستر — يحتاج Incode من الوكالة أو جهاز متخصص عند الفقد الكامل	\N	\N	\N	remote	\N	\N	\N	\N
7267f7c7-7722-43b3-bc48-94681201ab93	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2003	2007	gcc	Texas Instruments 4D-63 (PATS 3)	H84 / لِيشي: FO21	315 MHz	obd	يدوية بمفتاحين سليمين، أو OBD (Incode/Outcode) عند الفقد الكامل	وحدة PATS خلف الكلستر	\N	\N	\N	remote	\N	\N	\N	\N
6d7edf56-8fd0-4071-83cb-918830912add	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2008	2011	us	Texas Instruments 4D-63 (PATS 4)	H84 / لِيشي: FO21	315 MHz	obd	OBD مطلوب غالباً (Smart Pro / AutoProPad) — الطريقة اليدوية محدودة الفعالية في هذا الجيل	وحدة PATS / BCM — خلف الكلستر	\N	\N	\N	remote	\N	\N	\N	\N
7a12f7cc-7f7f-409e-8b55-6aac1caf33ca	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2008	2011	gcc	Texas Instruments 4D-63 (PATS 4)	H84 / لِيشي: FO21	315 MHz	obd	OBD مطلوب غالباً	وحدة PATS / BCM	\N	\N	\N	remote	\N	\N	\N	\N
8fdb9dae-52d4-47db-a032-5a77126b711e	2026-08-31 12:28:38.645175+00	تويوتا	كورولا	2007	2013	gcc	4D	toy43	433	manual			\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788189589921_1000112017.jpg	\N	remote	\N	\N	\N	\N
40d155f2-2965-4e6c-90e6-8c9a6499fa3b	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2016	2020	gcc	Toyota H-Chip (128-bit AES)	TOY44D / لِيشي: TOY44	433 MHz	obd	OBD إلزامي - Smart Pro / AutoProPad	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
eabb98f3-44c7-4245-87c1-b5138ef239cf	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2021	2024	gcc	Toyota H-Chip / بعض الفئات مفتاح ذكي	TOY44D	433 MHz	obd	OBD + تصريح أونلاين للفئات ذات المفتاح الذكي	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N
dffb1c16-054b-47bb-b054-aa162163133a	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	1998	2007	gcc	Toyota 4D-67/4D-68	TOY43/44 / لِيشي: TOY43	433 MHz	obd	يدوي بمفتاحين سليمين أحياناً، وإلا OBD	ECU / BCM حسب الفئة	\N	\N	\N	remote	\N	\N	\N	\N
b010d9df-ad5d-4f0b-95b1-caaabb5186d5	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2008	2015	gcc	Toyota G-Chip (128-bit)	TOY44 / لِيشي: TOY44	433 MHz	obd	OBD إلزامي غالباً	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
fdaa0b7d-eedf-4eac-8c1f-90d948c5f431	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2016	2021	gcc	Toyota H-Chip / مفتاح ذكي شائع	TOY44D	433 MHz	obd	OBD + تصريح أونلاين لفئات المفتاح الذكي	Smart Key ECU / BCM	\N	\N	\N	remote	\N	\N	\N	\N
1ac9811d-7395-4dda-abc8-ae8b0ef04d58	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2022	2024	gcc	Toyota H-Chip (AES) / مفتاح ذكي بالكامل	مفتاح ذكي - بدون شفرة تقليدية	433 MHz	obd	OBD + تصريح أونلاين من تويوتا (إلزامي تقريباً)	Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N
0f8bd9c5-27aa-484b-b25f-5d3cdb7c31a8	2026-09-01 08:03:29.022875+00	نيسان	باترول	1997	2001	gcc	بدون شريحة (بعض الفئات) / أو Nissan ID46 مبكر	NI04 / لِيشي: HU46	315 MHz	manual	يدوية بالكامل - قص وبرمجة مباشرة بدون جهاز في الفئات بدون مناعة	لا يوجد EEPROM في الفئات بدون مناعة	\N	\N	\N	remote	\N	\N	\N	\N
f7ae5bd2-632c-4cb6-ba2b-3b1fdb614e32	2026-09-01 08:03:29.022875+00	نيسان	باترول	2002	2010	gcc	Nissan ID46 (PCF7936)	NI04 / لِيشي: NI05	433 MHz	obd	OBD غالباً، يدوي أحياناً بمفتاحين سليمين	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
55b3aa7b-0eb9-4cdc-ba90-650a9c881189	2026-09-01 08:03:29.022875+00	نيسان	باترول	2010	2019	gcc	Nissan ID46 / Hitag - مفتاح ذكي شائع	مفتاح ذكي (Emergency: NI04)	433 MHz	obd	OBD إلزامي - Smart Pro / AutoProPad	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N
67bebb5a-b806-46d7-a8c6-eea9ca20d196	2026-09-01 08:03:29.022875+00	نيسان	باترول	2020	2024	gcc	Hitag AES - مفتاح ذكي بالكامل	مفتاح ذكي	433 MHz	obd	OBD + تصريح أونلاين لبعض الفئات	Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N
20e92fd8-b6d1-497a-be3c-9605ed7b9859	2026-09-01 08:03:29.022875+00	نيسان	صني	2011	2016	gcc	Nissan ID46 (PCF7936)	NSN14 / لِيشي: NSN14	433 MHz	obd	OBD غالباً، يدوي أحياناً بمفتاحين سليمين	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
65ea49c5-5c3e-427a-8932-d4cee481abc0	2026-09-01 08:03:29.022875+00	نيسان	صني	2017	2024	gcc	Nissan ID46 / Hitag2	NSN14 / لِيشي: NSN14	433 MHz	obd	OBD إلزامي غالباً	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
91ad8f7e-6253-42ad-92a7-c15dcba312a7	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2012	2018	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code (SMARTRA)، وإلا OBD	BCM خلف لوحة القيادة	\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788270104611_1000112511.jpg	\N	remote	\N	\N	\N	\N
e1141967-27bd-4dce-97c2-366124597fbf	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2017	2020	gcc	Hitag2 / NCF29A1 (انتقالي)	HY15 / بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً، مفتاح ذكي يحتاج تصريح أونلاين أحياناً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
361940f1-07b4-467d-8978-d2724d7b1ee6	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2021	2024	gcc	NCF29A1 / Hitag3 - مفتاح ذكي شائع	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي غالباً	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
24751d5b-d68a-4072-884e-855d15314400	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2010	2015	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
8b7ef6b9-63b3-428b-9f65-f214ca2da39a	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2016	2020	gcc	Hitag2 - مفتاح ذكي شائع بالفئات العليا	HY15 / مفتاح ذكي بالفئات العليا	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
8d99a077-0360-4deb-88ef-e196d337ad84	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2021	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
34370653-4629-4380-8463-f1518b3a044f	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2011	2016	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code (SMARTRA)، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
3b772e99-b163-4a81-b110-270654b102e4	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2017	2021	gcc	Hitag2 - مفتاح ذكي شائع بالفئات العليا	HY15 / مفتاح ذكي بالفئات العليا	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
990248c8-06eb-4c75-8ef2-ef4ec1af9743	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2022	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر كيا	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
3b67443e-fc28-43e7-a8b3-98d216ea9702	2026-09-01 08:03:29.022875+00	كيا	سيراتو	2013	2018	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N
35422c2b-5061-4f93-b418-224ddb4c89a4	2026-09-01 08:03:29.022875+00	كيا	سيراتو	2019	2024	gcc	Hitag2 / NCF29A1	HY15 / بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N
a841916d-89e8-4fea-957f-f46693b4ef8b	2026-09-01 13:39:07.451982+00	هيونداي	إلنترا	2014	2017	gcc	46		95440-1M110  /433	obd			\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788269942223_1000112510.jpg	\N	remote	\N	\N	\N	\N
bddc93bd-7823-4831-882d-9366eab3e050	2026-09-02 21:54:59.791132+00	تويوتا	كامري (Camry)	2018	2024	gcc	Texas Crypto 8A (Page 1: A8 / A9 / AA)	TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK (مواصفات خليجية GCC)	obd	عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus		\N	\N	\N	remote	\N	\N	\N	\N
8d55a472-2057-4347-bee4-c79c577c50ae	2026-09-02 21:54:59.791132+00	تويوتا	كامري (Camry)	2012	2017	gcc	4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)	TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)	433.92 MHz ASK	obd	برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
f3c3598b-d841-418f-ae24-5b46dd81712e	2026-09-02 21:54:59.791132+00	تويوتا	لاند كروزر (Land Cruiser V8 / LC300)	2016	2023	gcc	Texas Crypto 8A (Page 1: F3 / A9 / AA)	TOY48 / TOY2 / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK Dual Frequency	obd	برمجة مباشرة OBD II مع دعم محاكي Emulator في حالة All Keys Lost — الأجهزة الموصى بها: Autel MaxiIM IM608 Pro II / Key Tool Plus / Lonsdor K518ISE		\N	\N	\N	remote	\N	\N	\N	\N
f30bbb58-c435-4669-a8e0-48aebb103e43	2026-09-02 21:54:59.791132+00	هيونداي	سوناتا (Sonata)	2020	2024	gcc	Hitag AES / NCF29A1X (ID47)	HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)	433.92 MHz FSK	obd	برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor		\N	\N	\N	remote	\N	\N	\N	\N
ec202f86-b13f-4ffe-b695-ed393a4c85d7	2026-09-02 21:54:59.791132+00	هيونداي	إلنترا (Elantra)	2016	2020	gcc	ID47 Hitag3	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
2eace631-9b34-4581-a4a4-43d0e9885e01	2026-09-02 21:54:59.791132+00	نيسان	باترول (Patrol Y62)	2010	2023	gcc	ID46 PCF7952 / Hitag2 / AES (حسب الموديل)	NSN14 / لِيشي: Lishi NSN14 (2-in-1)	433.92 MHz FSK	obd	برمجة OBD II مع قراءة رمز BCM وحسابه إلى 20-Digit أو 4-Digit PIN — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
a5279a30-c05b-44d5-aab8-df5ffe8bc58f	2026-09-02 21:54:59.791132+00	نيسان	ألتيما (Altima)	2019	2024	gcc	Hitag AES (ID4A / NCF29A1M)	NSN14 / لِيشي: Lishi NSN14	433.92 MHz FSK (GCC Specs)	obd	عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
8434840c-8962-4804-8f33-d888597eb635	2026-09-02 21:54:59.791132+00	لكزس	LX570 / LX600	2016	2024	gcc	Texas Crypto 8A / Page 1: A9/AA/F3	TOY48 / TOY2 / لِيشي: Lishi TOY48	433.92 MHz FSK Dual	obd	عن طريق OBD II مباشرة مع خيار إضافة مفتاح ذكي أو كرت لكزس Smart Card — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / Lonsdor		\N	\N	\N	remote	\N	\N	\N	\N
36856840-2525-472e-83c7-2fc0c22f1d84	2026-09-02 21:54:59.791132+00	كيا	سبورتاج (Sportage)	2017	2022	gcc	Hitag3 (ID47)	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
6ca3e637-32c0-469c-8503-b9992f5b1148	2026-09-02 21:54:59.791132+00	فورد	تورس (Taurus)	2015	2023	gcc	Hitag Pro / ID49 / Texas 128-Bit	HU101 / لِيشي: Lishi HU101 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR	جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)	\N	\N	\N	remote	\N	\N	\N	\N
24736680-121d-4582-8763-4d9997105895	2026-09-02 21:54:59.791132+00	جمس / شيفروليه	يوكن / تاهو / سييرا (Yukon / Tahoe / Sierra)	2015	2020	gcc	Hitag Pro (ID46 / ID49 GM)	HU100 (Laser Cut) / لِيشي: Lishi HU100 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق منفذ OBD II مع عد أمان تنازلي 10 - 12 دقيقة (12 Min Security Pass) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR X300	جيب البرمجة داخل مسند الذراع الأوسط / الكونسول (Key Pocket)	\N	\N	\N	remote	\N	\N	\N	\N
6bd3e5e6-4c1c-46f5-9e9f-0ee3850dc14a	2026-09-02 21:54:59.791132+00	هوندا	أكورد (Accord)	2018	2023	gcc	Hitag3 (ID47 Honda)	HON66 (Laser Cut 4 Track) / لِيشي: Lishi HON66 (2-in-1)	433.92 MHz FSK	obd	برمجة مباشرة عبر OBD II بدون الحاجة لرموز أمان معقدة — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
84da66f8-3055-4595-a4de-e3341b4ed40b	2026-09-02 21:54:59.791132+00	مازدا	مازدا 6 (Mazda 6 / CX-5)	2016	2023	gcc	ID49 Hitag Pro	MAZ24R / MAZ20 / لِيشي: Lishi MAZ24 / MAZ20	433.92 MHz FSK	obd	عن طريق منفذ OBD II مباشرة بخطوتين سهلتين — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus		\N	\N	\N	remote	\N	\N	\N	\N
6b3c38a3-2571-4e6e-a6ea-2fbc2f4ce02e	2026-09-02 21:54:59.791132+00	إيسوزو	ديماكس (D-Max / MUX)	2020	2024	gcc	ID46 / Hitag AES	ISU5 / HU100 / لِيشي: Lishi ISU5 / HU100	433.92 MHz	obd	عن طريق OBD II مباشرة مع رمز PIN Code الإيسوزو — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N
16d601a7-d6b4-40d0-bfeb-009fc576377f	2026-09-02 21:54:59.791132+00	شأنغان	ألسفن / السفن / CS95 / Uni-K	2020	2024	gcc	Hitag3 (ID47) / Hitag AES	HU92 / HU100 / Changan Custom / لِيشي: Lishi HU92 / HU100	433.92 MHz FSK	obd	عن طريق OBD II باستخدام أجهزة متخصصة للسيارات الصينية — الأجهزة الموصى بها: Autel KM100 / OBDSTAR X300 DP Plus / Lonsdor K518		\N	\N	\N	remote	\N	\N	\N	\N
a672f727-345b-4444-b181-c54ef3787d74	2026-09-02 22:26:01.958576+00	تويوتا	كامري (Camry)	2018	2024	gcc	Texas Crypto 8A (Page 1: A8 / A9 / AA)	TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK (مواصفات خليجية GCC)	obd	عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus		\N	\N	\N	\N	\N	\N	\N	\N
429ed3c4-5ff1-423d-b221-cc0ee4ff2b03	2026-09-02 22:26:01.958576+00	تويوتا	كامري (Camry)	2012	2017	gcc	4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)	TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)	433.92 MHz ASK	obd	برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
b2b2b733-d225-4054-90e0-2f97978b7386	2026-09-02 22:26:01.958576+00	تويوتا	لاند كروزر (Land Cruiser V8 / LC300)	2016	2023	gcc	Texas Crypto 8A (Page 1: F3 / A9 / AA)	TOY48 / TOY2 / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK Dual Frequency	obd	برمجة مباشرة OBD II مع دعم محاكي Emulator في حالة All Keys Lost — الأجهزة الموصى بها: Autel MaxiIM IM608 Pro II / Key Tool Plus / Lonsdor K518ISE		\N	\N	\N	\N	\N	\N	\N	\N
f3dcd12b-be35-4557-8d2e-44c108a209f2	2026-09-02 22:26:01.958576+00	هيونداي	سوناتا (Sonata)	2020	2024	gcc	Hitag AES / NCF29A1X (ID47)	HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)	433.92 MHz FSK	obd	برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor		\N	\N	\N	\N	\N	\N	\N	\N
ff888159-4d1b-465e-90bf-0c01bfac5f5f	2026-09-02 22:26:01.958576+00	هيونداي	إلنترا (Elantra)	2016	2020	gcc	ID47 Hitag3	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
4b8722d0-2b53-4933-88b3-b9bce37442f3	2026-09-02 22:26:01.958576+00	نيسان	باترول (Patrol Y62)	2010	2023	gcc	ID46 PCF7952 / Hitag2 / AES (حسب الموديل)	NSN14 / لِيشي: Lishi NSN14 (2-in-1)	433.92 MHz FSK	obd	برمجة OBD II مع قراءة رمز BCM وحسابه إلى 20-Digit أو 4-Digit PIN — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
55a79da5-02d4-4e4f-a561-72d5f71ff1ee	2026-09-02 22:26:01.958576+00	لكزس	LX570 / LX600	2016	2024	gcc	Texas Crypto 8A / Page 1: A9/AA/F3	TOY48 / TOY2 / لِيشي: Lishi TOY48	433.92 MHz FSK Dual	obd	عن طريق OBD II مباشرة مع خيار إضافة مفتاح ذكي أو كرت لكزس Smart Card — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / Lonsdor		\N	\N	\N	\N	\N	\N	\N	\N
a622869d-8a5c-410c-a76d-4c9975b8b1db	2026-09-02 22:26:01.958576+00	كيا	سبورتاج (Sportage)	2017	2022	gcc	Hitag3 (ID47)	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
5c7840d5-e8db-4f60-9588-ce57b75164c2	2026-09-02 22:26:01.958576+00	فورد	تورس (Taurus)	2015	2023	gcc	Hitag Pro / ID49 / Texas 128-Bit	HU101 / لِيشي: Lishi HU101 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR	جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)	\N	\N	\N	\N	\N	\N	\N	\N
582c14d2-537e-41ed-928f-fb2ec7a05c6e	2026-09-02 22:26:01.958576+00	جمس / شيفروليه	يوكن / تاهو / سييرا (Yukon / Tahoe / Sierra)	2015	2020	gcc	Hitag Pro (ID46 / ID49 GM)	HU100 (Laser Cut) / لِيشي: Lishi HU100 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق منفذ OBD II مع عد أمان تنازلي 10 - 12 دقيقة (12 Min Security Pass) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR X300	جيب البرمجة داخل مسند الذراع الأوسط / الكونسول (Key Pocket)	\N	\N	\N	\N	\N	\N	\N	\N
ca2f2c88-a536-4870-81af-7ff69fa525c1	2026-09-02 22:26:01.958576+00	هوندا	أكورد (Accord)	2018	2023	gcc	Hitag3 (ID47 Honda)	HON66 (Laser Cut 4 Track) / لِيشي: Lishi HON66 (2-in-1)	433.92 MHz FSK	obd	برمجة مباشرة عبر OBD II بدون الحاجة لرموز أمان معقدة — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
6ebdb222-40fb-4607-9810-b3e2936b00e6	2026-09-02 22:26:01.958576+00	مازدا	مازدا 6 (Mazda 6 / CX-5)	2016	2023	gcc	ID49 Hitag Pro	MAZ24R / MAZ20 / لِيشي: Lishi MAZ24 / MAZ20	433.92 MHz FSK	obd	عن طريق منفذ OBD II مباشرة بخطوتين سهلتين — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus		\N	\N	\N	\N	\N	\N	\N	\N
def6d4f4-7c83-4ceb-822b-a733374f9f0e	2026-09-02 22:26:01.958576+00	إيسوزو	ديماكس (D-Max / MUX)	2020	2024	gcc	ID46 / Hitag AES	ISU5 / HU100 / لِيشي: Lishi ISU5 / HU100	433.92 MHz	obd	عن طريق OBD II مباشرة مع رمز PIN Code الإيسوزو — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N
372326bc-c180-4fc0-939b-82e2c7490a63	2026-09-02 22:26:01.958576+00	شأنغان	ألسفن / السفن / CS95 / Uni-K	2020	2024	gcc	Hitag3 (ID47) / Hitag AES	HU92 / HU100 / Changan Custom / لِيشي: Lishi HU92 / HU100	433.92 MHz FSK	obd	عن طريق OBD II باستخدام أجهزة متخصصة للسيارات الصينية — الأجهزة الموصى بها: Autel KM100 / OBDSTAR X300 DP Plus / Lonsdor K518		\N	\N	\N	\N	\N	\N	\N	\N
fce6f926-aff3-4cbc-a388-c095e5b4c283	2026-09-02 22:26:01.958576+00	نيسان	ألتيما (Altima)	2019	2024	gcc	Hitag AES (ID4A / NCF29A1M)	NSN14 / لِيشي: Lishi NSN14	433.92 MHz FSK (GCC Specs)	obd	عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR		\N	\N		smart				
\.


--
-- Data for Name: lishi_tools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lishi_tools (id, tool_name, blade_code, supported_cars, cut_positions, pick_direction, notes, created_at) FROM stdin;
1	Lishi TOY43AT (2-in-1)	TOY43	تويوتا كامري، أوريون، يارس، كورولا، هايلكس، برادو (2000 - 2017)	10 اسطوانات (Flat 10-Cut) / قراءة من 1 إلى 10	فتح مع اتجاه عقارب الساعة للباب الأيسر للسائق	الأسطوانات 1 و 2 تكون عادة مسؤولة عن فتح الشنطة، بينما 3-10 تفتح السلف والأبواب.	2026-09-02 23:46:15.688185+00
2	Lishi TOY48 (2-in-1)	TOY48 / TOY2	تويوتا لاندكروزر، كامري بصمة، لكزس LX570, ES350, LS460	4 مسارات داخلية (4-Track Inner Cut) / 8 اسطوانات	التقاط الاسطوانات حسب النظام المزدوج (A & B)	تأكد من عدم الضغط بقوة على الريشة لتجنب كسر سناد القفل الداخلي لسلندر لكزس.	2026-09-02 23:46:15.688185+00
3	Lishi HY22 (2-in-1)	HY22	هيونداي سوناتا، إلنترا، توسان، أزيرا / كيا سبورتاج، أوبتيما، سيراتو	4 مسارات ليزر (4-Track Laser Cut) / 8 أو 12 اسطوانة	الفتح باتجاه مقدمة السيارة	شائعة جداً في السيارات الكورية. انتبه للفرق بين موديلات 8 كليكس و 12 كليكس.	2026-09-02 23:46:15.688185+00
4	Lishi NSN14 (2-in-1)	NSN14	نيسان باترول Y62، ألتيما، صني، مكسيما، نافارا / إنفينيتي QX80	10 اسطوانات مقسمة على الجانبين (5 على كل جانب)	عكس اتجاه عقارب الساعة للأبواب الخليجية	يجب الضغط الخفيف جداً عند فك قفل BCM نيسان لمنع التعليق.	2026-09-02 23:46:15.688185+00
5	Lishi HU100 (2-in-1)	HU100	جمس يوكن، سييرا / شيفروليه تاهو، كابريس، ماليبو / أوبل	مسارين ليزر (2-Track Laser Cut) / 8 أو 10 اسطوانات	التقاط المسارات العلوي والسفلي بالتناوب	تستخدم لسيارات جنرال موتورز حديثة من 2010 إلى 2023.	2026-09-02 23:46:15.688185+00
6	Lishi HON66 (2-in-1)	HON66	هوندا أكورد، سيفيك، CR-V، أوديسي / أكيورا	4 مسارات ليزر / قراءة اسطوانات المقابض	باتجاه الخلف لفتح الباب	سلاسل هوندا تتطلب تنظيف السلندر بالبخاخ المنظف قبل التقاط الأسطوانات.	2026-09-02 23:46:15.688185+00
7	Lishi HU101 (2-in-1)	HU101	فورد تورس، إكسبلورر، F-150، فلكس / فولفو	10 اسطوانات مسار خارجي	مع اتجاه العقارب للباب الأمامي	تحديد عمق Cut 1 إلى 4 بدقة على ماكينات القص الكهروميكانيكية.	2026-09-02 23:46:15.688185+00
8	Lishi HU66 (2-in-1)	HU66	فولكس واجن، أودي، بورش، سيات، سكودا	8 اسطوانات مسارين ليزر	التقاط متعامد	الموديلات الأوروبية وتتطلب محول فك سريع.	2026-09-02 23:46:15.688185+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, role, status, display_name, workshop_name, city, license_ref_hash, mfa_required, locked_until, created_at, updated_at) FROM stdin;
796b0d23-5e2b-4a05-a18d-311eb39c6c11	super_admin	verified	\N	\N	\N	\N	t	\N	2026-09-02 23:51:39.757992+00	2026-09-02 23:51:39.757992+00
\.


--
-- Data for Name: rate_limit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_limit_events (id, actor_key, action, created_at) FROM stdin;
1	a:e59bc992ccc99da1d538e7713bea98fcadeced22c78447d93e45d3ea72cd11aa	search_cars	2026-09-03 00:40:46.518578+00
2	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:42:50.215426+00
3	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:43:00.523169+00
4	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:44:12.088123+00
5	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:46:41.243946+00
6	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-03 01:16:21.627246+00
7	a:98164a5aed7b82d5c6f5104e2d2e0a8c87b5d879c8858e68cb0f7db1f691f9b7	search_cars	2026-09-03 04:20:40.04203+00
\.


--
-- Data for Name: work_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_log (id, technician_id, car_ref, job_type, vin_fingerprint, notes, created_at) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 4, true);


--
-- Name: lishi_tools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lishi_tools_id_seq', 8, true);


--
-- Name: rate_limit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rate_limit_events_id_seq', 7, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: cars_key_data cars_key_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cars_key_data
    ADD CONSTRAINT cars_key_data_pkey PRIMARY KEY (id);


--
-- Name: lishi_tools lishi_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lishi_tools
    ADD CONSTRAINT lishi_tools_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_events rate_limit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_events
    ADD CONSTRAINT rate_limit_events_pkey PRIMARY KEY (id);


--
-- Name: work_log work_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_log
    ADD CONSTRAINT work_log_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor ON public.audit_log USING btree (actor_id, created_at DESC);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_cars_key_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_key_type ON public.cars_key_data USING btree (key_type);


--
-- Name: idx_cars_make; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make ON public.cars_key_data USING btree (make);


--
-- Name: idx_cars_make_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make_model ON public.cars_key_data USING btree (make, model);


--
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- Name: idx_profiles_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_status ON public.profiles USING btree (status);


--
-- Name: idx_rate_limit_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limit_lookup ON public.rate_limit_events USING btree (actor_key, action, created_at DESC);


--
-- Name: idx_work_log_tech; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_log_tech ON public.work_log USING btree (technician_id, created_at DESC);


--
-- Name: cars_key_data trg_audit_cars; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_cars AFTER INSERT OR DELETE OR UPDATE ON public.cars_key_data FOR EACH ROW EXECUTE FUNCTION public.record_audit();


--
-- Name: profiles trg_audit_profiles; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_profiles AFTER INSERT OR DELETE OR UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.record_audit();


--
-- Name: profiles trg_profiles_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_guard BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.guard_profile_privileges();


--
-- Name: profiles trg_profiles_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: work_log work_log_technician_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_log
    ADD CONSTRAINT work_log_technician_id_fkey FOREIGN KEY (technician_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_admin_read ON public.audit_log FOR SELECT TO authenticated USING (public.is_super_admin());


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: cars_key_data cars_admin_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cars_admin_write ON public.cars_key_data TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: cars_key_data; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cars_key_data ENABLE ROW LEVEL SECURITY;

--
-- Name: cars_key_data cars_locksmith_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cars_locksmith_read ON public.cars_key_data FOR SELECT TO authenticated USING (public.is_verified_locksmith());


--
-- Name: lishi_tools lishi_admin_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lishi_admin_write ON public.lishi_tools TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: lishi_tools lishi_locksmith_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lishi_locksmith_read ON public.lishi_tools FOR SELECT TO authenticated USING (public.is_verified_locksmith());


--
-- Name: lishi_tools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lishi_tools ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_admin_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_admin_all ON public.profiles TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: profiles profiles_select_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_admin ON public.profiles FOR SELECT TO authenticated USING (public.is_super_admin());


--
-- Name: profiles profiles_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_own ON public.profiles FOR SELECT TO authenticated USING ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: profiles profiles_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE TO authenticated USING ((id = ( SELECT auth.uid() AS uid))) WITH CHECK ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: rate_limit_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: work_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_log ENABLE ROW LEVEL SECURITY;

--
-- Name: work_log work_log_own_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_delete ON public.work_log FOR DELETE TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- Name: work_log work_log_own_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_insert ON public.work_log FOR INSERT TO authenticated WITH CHECK (((technician_id = ( SELECT auth.uid() AS uid)) AND public.is_verified_locksmith()));


--
-- Name: work_log work_log_own_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_select ON public.work_log FOR SELECT TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- Name: work_log work_log_own_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_update ON public.work_log FOR UPDATE TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid))) WITH CHECK ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- PostgreSQL database dump complete
--

\unrestrict cIv5xNCN32K76yFCWqrAQHwa70xfOBa2HtJ1ZIAquL9waN1R8nvZDWEdgcTguWp


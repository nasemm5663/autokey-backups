--
-- PostgreSQL database dump
--

\restrict sV5mbeanczt1tM4uE0tp6A6BCWCpbhClbs9SR8of5ZwkK6Dtumivl3Mbd1DMjQC

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.account_status AS ENUM (
    'pending',
    'verified',
    'suspended'
);


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'guest',
    'locksmith',
    'super_admin'
);


--
-- Name: contrib_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.contrib_status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: actor_fingerprint(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.actor_fingerprint() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                        DECLARE
                                                                                                                                          v_uid    UUID;
                                                                                                                                            v_ip     TEXT;
                                                                                                                                              v_pepper TEXT;
                                                                                                                                              BEGIN
                                                                                                                                                v_uid := (SELECT auth.uid());
                                                                                                                                                  IF v_uid IS NOT NULL THEN
                                                                                                                                                      RETURN 'u:' || v_uid::text;
                                                                                                                                                        END IF;

                                                                                                                                                          BEGIN
                                                                                                                                                              v_ip := current_setting('request.headers', true)::json ->> 'x-forwarded-for';
                                                                                                                                                                EXCEPTION WHEN OTHERS THEN
                                                                                                                                                                    v_ip := NULL;
                                                                                                                                                                      END;

                                                                                                                                                                        BEGIN
                                                                                                                                                                            v_pepper := public.get_pepper('autokey_fingerprint_pepper');
                                                                                                                                                                              EXCEPTION WHEN OTHERS THEN
                                                                                                                                                                                  v_pepper := 'fallback-rate-limit-salt';
                                                                                                                                                                                    END;

                                                                                                                                                                                      RETURN 'a:' || encode(
                                                                                                                                                                                          sha256(convert_to(v_pepper || ':' || coalesce(v_ip, 'unknown') || ':' || v_pepper, 'UTF8')),
                                                                                                                                                                                              'hex'
                                                                                                                                                                                                );
                                                                                                                                                                                                END;
                                                                                                                                                                                                $$;


--
-- Name: admin_add_image(text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_add_image(p_car_id text, p_url text, p_kind text DEFAULT 'other'::text, p_caption text DEFAULT NULL::text) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                    DECLARE v_id BIGINT; v_next INT;
                                                                                    BEGIN
                                                                                      IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                          RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                                                                                                USING ERRCODE = 'insufficient_privilege';
                                                                                                  END IF;

                                                                                                    -- نرفض أي رابط ليس http/https (يمنع javascript: و data:)
                                                                                                      IF p_url !~* '^https?://' THEN
                                                                                                          RAISE EXCEPTION 'رابط الصورة يجب أن يبدأ بـ http أو https.'
                                                                                                                USING ERRCODE = 'invalid_parameter_value';
                                                                                                                  END IF;

                                                                                                                    IF p_kind NOT IN ('remote','board','lishi','key','tool','other') THEN
                                                                                                                        RAISE EXCEPTION 'نوع صورة غير معروف.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                          END IF;

                                                                                                                            SELECT coalesce(max(sort_order), -1) + 1 INTO v_next
                                                                                                                              FROM public.car_images WHERE car_id = p_car_id;

                                                                                                                                INSERT INTO public.car_images (car_id, url, kind, caption, sort_order, added_by)
                                                                                                                                  VALUES (p_car_id, btrim(p_url), p_kind,
                                                                                                                                            nullif(btrim(coalesce(p_caption,'')),''), v_next, (SELECT auth.uid()))
                                                                                                                                              RETURNING id INTO v_id;

                                                                                                                                                RETURN v_id;
                                                                                                                                                END;
                                                                                                                                                $$;


--
-- Name: admin_car_images(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_car_images(p_car_id text) RETURNS TABLE(id bigint, url text, kind text, caption text, sort_order integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                BEGIN
                                                                  IF NOT public.is_super_admin() THEN
                                                                      RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                        END IF;
                                                                          RETURN QUERY
                                                                            SELECT i.id, i.url::text, i.kind::text, i.caption::text, i.sort_order
                                                                              FROM public.car_images i
                                                                                WHERE i.car_id = p_car_id
                                                                                  ORDER BY i.sort_order, i.id;
                                                                                  END;
                                                                                  $$;


--
-- Name: admin_contrib_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_contrib_count() RETURNS integer
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  DECLARE v INT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    IF NOT public.is_super_admin() THEN RETURN 0; END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      SELECT count(*)::int INTO v FROM public.contributions
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        WHERE status = 'pending'::public.contrib_status;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          RETURN coalesce(v,0);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          $$;


--
-- Name: admin_create_workshop(text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_create_workshop(p_name text, p_city text, p_owner_email text, p_seats integer DEFAULT 3) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                  DECLARE v_uid UUID; v_ws UUID;
                                                                                                                                                                                                                                                                                                                                                                                                                  BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                    IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                                                                                                                        RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                                                                                                                                                                                                                                                                                                                                                                                                                              USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                  SELECT u.id INTO v_uid FROM auth.users u WHERE lower(u.email) = lower(btrim(p_owner_email));
                                                                                                                                                                                                                                                                                                                                                                                                                                    IF v_uid IS NULL THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                        RAISE EXCEPTION 'لا يوجد حساب بهذا البريد. اطلب منه التسجيل أولاً.'
                                                                                                                                                                                                                                                                                                                                                                                                                                              USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                                                                                                                                                                END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                  INSERT INTO public.workshops (name, city, owner_id, seat_limit)
                                                                                                                                                                                                                                                                                                                                                                                                                                                    VALUES (btrim(p_name), nullif(btrim(coalesce(p_city,'')),''), v_uid,
                                                                                                                                                                                                                                                                                                                                                                                                                                                              greatest(1, least(coalesce(p_seats,3), 200)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                RETURNING id INTO v_ws;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                  UPDATE public.profiles
                                                                                                                                                                                                                                                                                                                                                                                                                                                                    SET workshop_id = v_ws, workshop_role = 'owner',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                          role = 'locksmith'::public.app_role,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                status = 'verified'::public.account_status
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  WHERE id = v_uid;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    RETURN v_ws;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    $$;


--
-- Name: admin_delete_image(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_delete_image(p_id bigint) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                BEGIN
                                                                                                                                                  IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                      RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                        END IF;
                                                                                                                                                          DELETE FROM public.car_images WHERE id = p_id;
                                                                                                                                                            IF NOT FOUND THEN
                                                                                                                                                                RAISE EXCEPTION 'الصورة غير موجودة.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                  END IF;
                                                                                                                                                                    RETURN 'تم الحذف.';
                                                                                                                                                                    END;
                                                                                                                                                                    $$;


--
-- Name: ar_base(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ar_base(p_text text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO ''
    AS $_$
                                                                                                                                                                                                                                                                                                                                                                            SELECT btrim(
                                                                                                                                                                                                                                                                                                                                                                                regexp_replace(
                                                                                                                                                                                                                                                                                                                                                                                      regexp_replace(
                                                                                                                                                                                                                                                                                                                                                                                              regexp_replace(public.ar_normalize(p_text), '\([^)]*\)', ' ', 'g'),
                                                                                                                                                                                                                                                                                                                                                                                                    '\s+', ' ', 'g'),
                                                                                                                                                                                                                                                                                                                                                                                                        '[\s/\-]+$', '')
                                                                                                                                                                                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                                                                                                                                                                                          $_$;


--
-- Name: FUNCTION ar_base(p_text text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.ar_base(p_text text) IS 'الاسم الأساسي للمقارنة: تطبيع عربي + إزالة الاسم الإنجليزي بين الأقواس';


--
-- Name: ar_normalize(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ar_normalize(p_text text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO ''
    AS $$
  SELECT lower(btrim(regexp_replace(
      translate(
            coalesce(p_text, ''),
                  'أإآٱىةؤئ٠١٢٣٤٥٦٧٨٩کیچپگژًٌٍَُِّْٰـ',
                        'اااايهوي0123456789كيجبكز'
                            ),
                                '\s+', ' ', 'g')));
                                $$;


--
-- Name: FUNCTION ar_normalize(p_text text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.ar_normalize(p_text text) IS 'توحيد صور الحروف العربية للبحث: أإآٱ←ا، ى←ي، ة←ه، ؤ←و، ئ←ي، حذف التشكيل والتطويل';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cars_key_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cars_key_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year_from integer NOT NULL,
    year_to integer NOT NULL,
    market text DEFAULT 'gcc'::text,
    transponder_type text,
    key_blade text,
    remote_frequency text,
    programming_type text,
    programming_details text,
    eeprom_location text,
    image_url text,
    board_image_url text,
    fcc_id text,
    key_type text,
    oem_part_number text,
    special_requirements text,
    execution_steps text,
    warnings_notes text,
    make_norm text GENERATED ALWAYS AS (public.ar_normalize(make)) STORED,
    model_norm text GENERATED ALWAYS AS (public.ar_normalize(model)) STORED,
    make_base text GENERATED ALWAYS AS (public.ar_base(make)) STORED,
    model_base text GENERATED ALWAYS AS (public.ar_base(model)) STORED,
    data_source text,
    confidence text DEFAULT 'medium'::text NOT NULL,
    verified_at timestamp with time zone,
    source_note text,
    CONSTRAINT cars_confidence_check CHECK ((confidence = ANY (ARRAY['high'::text, 'medium'::text, 'low'::text]))),
    CONSTRAINT cars_key_data_key_type_check CHECK (((key_type IS NULL) OR (key_type = ANY (ARRAY['smart'::text, 'remote'::text, 'blade'::text]))))
);


--
-- Name: COLUMN cars_key_data.key_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cars_key_data.key_type IS 'نوع المفتاح: smart = بصمة، remote = مفتاح بريموت، blade = مفتاح عادي';


--
-- Name: COLUMN cars_key_data.data_source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cars_key_data.data_source IS 'مصدر المعلومة: MK3 / 3D Group / دليل المصنّع / خبرة فني...';


--
-- Name: COLUMN cars_key_data.confidence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cars_key_data.confidence IS 'high = مؤكد من مصدر رسمي، medium = مرجّح، low = يحتاج تحققاً';


--
-- Name: admin_get_record(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_get_record(p_id text) RETURNS SETOF public.cars_key_data
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                           BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                             IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                 RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                   END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                     RETURN QUERY SELECT * FROM public.cars_key_data c WHERE c.id::text = p_id;
                                                                                                                                                                                                                                                                                                                                                                                                                                     END;
                                                                                                                                                                                                                                                                                                                                                                                                                                     $$;


--
-- Name: admin_growth(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_growth(p_weeks integer DEFAULT 8) RETURNS TABLE(week_start date, new_users integer, new_cars integer, searches integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WITH weeks AS (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   SELECT generate_series(
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         date_trunc('week', now()) - ((p_weeks - 1) || ' weeks')::interval,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               date_trunc('week', now()),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     '1 week'::interval
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ) AS w
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           )
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             SELECT wk.w::date,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      (SELECT count(*)::int FROM public.profiles p
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                WHERE p.created_at >= wk.w AND p.created_at < wk.w + INTERVAL '1 week'),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         (SELECT count(*)::int FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   WHERE c.created_at >= wk.w AND c.created_at < wk.w + INTERVAL '1 week'),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            (SELECT count(*)::int FROM public.search_misses s
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      WHERE s.created_at >= wk.w AND s.created_at < wk.w + INTERVAL '1 week')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        FROM weeks wk
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ORDER BY 1;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          $$;


--
-- Name: admin_list_contributions(text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_list_contributions(p_status text DEFAULT 'pending'::text, p_limit integer DEFAULT 20, p_offset integer DEFAULT 0) RETURNS TABLE(id bigint, kind text, target_id text, payload jsonb, note text, status text, created_at timestamp with time zone, author_name text, author_email text, author_workshop text, target_label text, total_count bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        SELECT c.id, c.kind, c.target_id, c.payload, c.note,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 c.status::text, c.created_at,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          p.display_name::text, u.email::text, p.workshop_name::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   (SELECT k.make || ' ' || k.model || ' (' || k.year_from || '–' || k.year_to || ')'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FROM public.cars_key_data k WHERE k.id::text = c.target_id),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      count(*) OVER()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        FROM public.contributions c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          JOIN auth.users u    ON u.id = c.submitted_by
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            LEFT JOIN public.profiles p ON p.id = c.submitted_by
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              WHERE (p_status IS NULL OR p_status = '' OR c.status::text = p_status)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ORDER BY c.created_at DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  LIMIT greatest(1, least(p_limit,100)) OFFSET greatest(0, p_offset);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  $$;


--
-- Name: admin_list_technicians(text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_list_technicians(p_status text DEFAULT NULL::text, p_search text DEFAULT NULL::text, p_limit integer DEFAULT 25, p_offset integer DEFAULT 0) RETURNS TABLE(user_id uuid, email text, display_name text, workshop_name text, city text, role text, status text, has_license boolean, created_at timestamp with time zone, total_count bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                               DECLARE v_q TEXT;
                                                                                                                                                                                               BEGIN
                                                                                                                                                                                                 IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                     RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                                                                                                                                                                                                           USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                             END IF;

                                                                                                                                                                                                               v_q := public.ar_normalize(coalesce(p_search, ''));

                                                                                                                                                                                                                 RETURN QUERY
                                                                                                                                                                                                                   SELECT p.id, u.email::text, p.display_name::text, p.workshop_name::text,
                                                                                                                                                                                                                            p.city::text, p.role::text, p.status::text,
                                                                                                                                                                                                                                     (p.license_ref_hash IS NOT NULL), p.created_at,
                                                                                                                                                                                                                                              count(*) OVER()
                                                                                                                                                                                                                                                FROM public.profiles p
                                                                                                                                                                                                                                                  JOIN auth.users u ON u.id = p.id
                                                                                                                                                                                                                                                    WHERE (p_status IS NULL OR p_status = '' OR p.status::text = p_status)
                                                                                                                                                                                                                                                        AND (v_q = ''
                                                                                                                                                                                                                                                                 OR public.ar_normalize(coalesce(p.display_name,''))  LIKE '%' || v_q || '%'
                                                                                                                                                                                                                                                                          OR public.ar_normalize(coalesce(p.workshop_name,'')) LIKE '%' || v_q || '%'
                                                                                                                                                                                                                                                                                   OR lower(u.email::text) LIKE '%' || lower(coalesce(p_search,'')) || '%')
                                                                                                                                                                                                                                                                                     ORDER BY (p.status = 'pending'::public.account_status) DESC, p.created_at DESC
                                                                                                                                                                                                                                                                                       LIMIT greatest(1, least(p_limit, 100)) OFFSET greatest(0, p_offset);
                                                                                                                                                                                                                                                                                       END;
                                                                                                                                                                                                                                                                                       $$;


--
-- Name: admin_list_workshops(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_list_workshops(p_limit integer DEFAULT 20, p_offset integer DEFAULT 0) RETURNS TABLE(id uuid, name text, city text, owner_email text, seat_limit integer, seats_used integer, status text, created_at timestamp with time zone, total_count bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                SELECT w.id, w.name::text, w.city::text, u.email::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         w.seat_limit,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  (SELECT count(*)::int FROM public.profiles m WHERE m.workshop_id = w.id),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           w.status::text, w.created_at, count(*) OVER()
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FROM public.workshops w
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               LEFT JOIN auth.users u ON u.id = w.owner_id
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ORDER BY w.created_at DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   LIMIT greatest(1, least(p_limit,100)) OFFSET greatest(0, p_offset);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $$;


--
-- Name: admin_makes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_makes() RETURNS TABLE(make text, n integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                               BEGIN
                                                                                                                                                                                                                                                                                                 IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                     RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                       END IF;
                                                                                                                                                                                                                                                                                                         RETURN QUERY
                                                                                                                                                                                                                                                                                                           SELECT c.make::text, count(*)::int
                                                                                                                                                                                                                                                                                                             FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                               GROUP BY c.make ORDER BY 1;
                                                                                                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                                                                                                               $$;


--
-- Name: admin_models(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_models(p_make text) RETURNS TABLE(model text, n integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                               BEGIN
                                                                                                                                                                                                                                                                                                                 IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                     RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                       END IF;
                                                                                                                                                                                                                                                                                                                         RETURN QUERY
                                                                                                                                                                                                                                                                                                                           SELECT c.model::text, count(*)::int
                                                                                                                                                                                                                                                                                                                             FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                               WHERE c.make = p_make
                                                                                                                                                                                                                                                                                                                                 GROUP BY c.model ORDER BY 1;
                                                                                                                                                                                                                                                                                                                                 END;
                                                                                                                                                                                                                                                                                                                                 $$;


--
-- Name: admin_pending_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_pending_count() RETURNS integer
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                       DECLARE v_n INT;
                                                                                                                                                                                                                                                                                       BEGIN
                                                                                                                                                                                                                                                                                         IF NOT public.is_super_admin() THEN RETURN 0; END IF;
                                                                                                                                                                                                                                                                                           SELECT count(*)::int INTO v_n FROM public.profiles
                                                                                                                                                                                                                                                                                             WHERE status = 'pending'::public.account_status;
                                                                                                                                                                                                                                                                                               RETURN coalesce(v_n, 0);
                                                                                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                                                                                               $$;


--
-- Name: admin_popular_searches(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_popular_searches(p_days integer DEFAULT 30) RETURNS TABLE(query_norm text, times integer, avg_hits integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     SELECT m.query_norm, count(*)::int, round(avg(m.hits))::int
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       FROM public.search_misses m
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         WHERE m.created_at > now() - (p_days || ' days')::interval
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             AND m.hits > 0
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               GROUP BY m.query_norm
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ORDER BY 2 DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   LIMIT 25;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $$;


--
-- Name: admin_records(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_records(p_make text, p_model text) RETURNS TABLE(id text, year_from integer, year_to integer, market text, key_type text, confidence text, data_source text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                BEGIN
                                                                                                                                                                                                                                                                                                                                                  IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                      RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                        END IF;
                                                                                                                                                                                                                                                                                                                                                          RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                            SELECT c.id::text, c.year_from::int, c.year_to::int, c.market::text,
                                                                                                                                                                                                                                                                                                                                                                     c.key_type::text, c.confidence::text, c.data_source::text
                                                                                                                                                                                                                                                                                                                                                                       FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                         WHERE c.make = p_make AND c.model = p_model
                                                                                                                                                                                                                                                                                                                                                                           ORDER BY c.year_from DESC;
                                                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: admin_review_contribution(bigint, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_review_contribution(p_id bigint, p_decision text, p_note text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
      DECLARE
        c        public.contributions%ROWTYPE;
          v_author TEXT;
            v_new_id TEXT;
              v_prev   JSONB := NULL;
                v_img    JSONB;
                  v_n      INT := 0;
                  BEGIN
                    IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                        RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                              USING ERRCODE = 'insufficient_privilege';
                                END IF;
                                  IF p_decision NOT IN ('approved','rejected') THEN
                                      RAISE EXCEPTION 'قرار غير صحيح.' USING ERRCODE = 'invalid_parameter_value';
                                        END IF;

                                          SELECT * INTO c FROM public.contributions WHERE id = p_id;
                                            IF NOT FOUND THEN
                                                RAISE EXCEPTION 'المساهمة غير موجودة.' USING ERRCODE = 'no_data_found';
                                                  END IF;
                                                    IF c.status <> 'pending'::public.contrib_status THEN
                                                        RAISE EXCEPTION 'هذه المساهمة روجعت مسبقاً.' USING ERRCODE = 'invalid_parameter_value';
                                                          END IF;

                                                            SELECT coalesce(p.display_name, u.email) INTO v_author
                                                              FROM auth.users u LEFT JOIN public.profiles p ON p.id = u.id
                                                                WHERE u.id = c.submitted_by;

                                                                  IF p_decision = 'approved' THEN
                                                                      IF c.kind = 'new' THEN
                                                                            INSERT INTO public.cars_key_data (
                                                                                    make, model, year_from, year_to, market, key_type,
                                                                                            transponder_type, key_blade, remote_frequency,
                                                                                                    programming_type, programming_details, eeprom_location,
                                                                                                            fcc_id, oem_part_number, special_requirements,
                                                                                                                    execution_steps, warnings_notes,
                                                                                                                            data_source, confidence, source_note
                                                                                                                                  ) VALUES (
                                                                                                                                          btrim(c.payload ->> 'make'), btrim(c.payload ->> 'model'),
                                                                                                                                                  nullif(c.payload ->> 'year_from','')::int,
                                                                                                                                                          nullif(c.payload ->> 'year_to','')::int,
                                                                                                                                                                  coalesce(nullif(c.payload ->> 'market',''), 'gcc'),
                                                                                                                                                                          nullif(c.payload ->> 'key_type',''),
                                                                                                                                                                                  c.payload ->> 'transponder_type', c.payload ->> 'key_blade',
                                                                                                                                                                                          c.payload ->> 'remote_frequency',
                                                                                                                                                                                                  coalesce(nullif(c.payload ->> 'programming_type',''), 'manual'),
                                                                                                                                                                                                          c.payload ->> 'programming_details', c.payload ->> 'eeprom_location',
                                                                                                                                                                                                                  c.payload ->> 'fcc_id', c.payload ->> 'oem_part_number',
                                                                                                                                                                                                                          c.payload ->> 'special_requirements', c.payload ->> 'execution_steps',
                                                                                                                                                                                                                                  c.payload ->> 'warnings_notes',
                                                                                                                                                                                                                                          'مساهمة فني: ' || coalesce(v_author,'—'), 'medium', c.note
                                                                                                                                                                                                                                                )
                                                                                                                                                                                                                                                      RETURNING id::text INTO v_new_id;

                                                                                                                                                                                                                                                          ELSE
                                                                                                                                                                                                                                                                -- لقطة القيم قبل التعديل — بلا هذا لا يمكن التراجع فعلاً
                                                                                                                                                                                                                                                                      SELECT to_jsonb(k) INTO v_prev
                                                                                                                                                                                                                                                                            FROM public.cars_key_data k WHERE k.id::text = c.target_id;

                                                                                                                                                                                                                                                                                  IF v_prev IS NULL THEN
                                                                                                                                                                                                                                                                                          RAISE EXCEPTION 'السجل المقصود بالتصحيح لم يعد موجوداً.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                END IF;

                                                                                                                                                                                                                                                                                                      UPDATE public.cars_key_data k SET
                                                                                                                                                                                                                                                                                                              transponder_type     = CASE WHEN c.payload ? 'transponder_type'     THEN c.payload ->> 'transponder_type'     ELSE k.transponder_type END,
                                                                                                                                                                                                                                                                                                                      key_blade            = CASE WHEN c.payload ? 'key_blade'            THEN c.payload ->> 'key_blade'            ELSE k.key_blade END,
                                                                                                                                                                                                                                                                                                                              remote_frequency     = CASE WHEN c.payload ? 'remote_frequency'     THEN c.payload ->> 'remote_frequency'     ELSE k.remote_frequency END,
                                                                                                                                                                                                                                                                                                                                      programming_details  = CASE WHEN c.payload ? 'programming_details'  THEN c.payload ->> 'programming_details'  ELSE k.programming_details END,
                                                                                                                                                                                                                                                                                                                                              eeprom_location      = CASE WHEN c.payload ? 'eeprom_location'      THEN c.payload ->> 'eeprom_location'      ELSE k.eeprom_location END,
                                                                                                                                                                                                                                                                                                                                                      oem_part_number      = CASE WHEN c.payload ? 'oem_part_number'      THEN c.payload ->> 'oem_part_number'      ELSE k.oem_part_number END,
                                                                                                                                                                                                                                                                                                                                                              special_requirements = CASE WHEN c.payload ? 'special_requirements' THEN c.payload ->> 'special_requirements' ELSE k.special_requirements END,
                                                                                                                                                                                                                                                                                                                                                                      execution_steps      = CASE WHEN c.payload ? 'execution_steps'      THEN c.payload ->> 'execution_steps'      ELSE k.execution_steps END,
                                                                                                                                                                                                                                                                                                                                                                              warnings_notes       = CASE WHEN c.payload ? 'warnings_notes'       THEN c.payload ->> 'warnings_notes'       ELSE k.warnings_notes END,
                                                                                                                                                                                                                                                                                                                                                                                      source_note          = coalesce(k.source_note,'') || ' | تصحيح من: ' || coalesce(v_author,'—')
                                                                                                                                                                                                                                                                                                                                                                                            WHERE k.id::text = c.target_id;

                                                                                                                                                                                                                                                                                                                                                                                                  v_new_id := c.target_id;
                                                                                                                                                                                                                                                                                                                                                                                                      END IF;

                                                                                                                                                                                                                                                                                                                                                                                                          IF jsonb_typeof(c.payload -> 'images') = 'array' THEN
                                                                                                                                                                                                                                                                                                                                                                                                                FOR v_img IN SELECT * FROM jsonb_array_elements(c.payload -> 'images') LOOP
                                                                                                                                                                                                                                                                                                                                                                                                                        IF (v_img ->> 'url') ~* '^https?://' THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                  INSERT INTO public.car_images (car_id, url, kind, caption, sort_order, added_by)
                                                                                                                                                                                                                                                                                                                                                                                                                                            VALUES (v_new_id, v_img ->> 'url',
                                                                                                                                                                                                                                                                                                                                                                                                                                                        CASE WHEN (v_img ->> 'kind') IN ('remote','board','lishi','key','tool','other')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                         THEN v_img ->> 'kind' ELSE 'other' END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     coalesce(nullif(btrim(coalesce(v_img ->> 'caption','')),''), 'من: ' || coalesce(v_author,'فني')),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 1000 + v_n, c.submitted_by);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           v_n := v_n + 1;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END LOOP;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 UPDATE public.contributions
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   SET status = p_decision::public.contrib_status,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         reviewed_by = (SELECT auth.uid()), reviewed_at = now(),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               review_note = nullif(btrim(coalesce(p_note,'')),''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     applied_car_id = v_new_id,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           prev_data = v_prev
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             WHERE id = p_id;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RETURN coalesce(v_new_id, '');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               $$;


--
-- Name: admin_search_gaps(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_search_gaps(p_days integer DEFAULT 30) RETURNS TABLE(query_norm text, times integer, last_seen timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
BEGIN
  IF NOT public.is_super_admin() THEN
      RAISE EXCEPTION 'هذا التقرير للمدير فقط.' USING ERRCODE = 'insufficient_privilege';
        END IF;

          RETURN QUERY
            SELECT m.query_norm, count(*)::int, max(m.created_at)
              FROM public.search_misses m
                WHERE m.created_at > now() - (p_days || ' days')::interval
                    AND m.hits = 0            -- ← الشرط الناقص: الفاشلة فقط
                      GROUP BY m.query_norm
                        ORDER BY 2 DESC, 3 DESC
                          LIMIT 50;
                          END;
                          $$;


--
-- Name: admin_search_records(text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_search_records(p_q text, p_limit integer DEFAULT 30, p_offset integer DEFAULT 0) RETURNS TABLE(id text, make text, model text, year_from integer, year_to integer, market text, key_type text, total_count bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                            DECLARE v_q TEXT;
                                                                                                                                                                                                                                                                                                                                                                                            BEGIN
                                                                                                                                                                                                                                                                                                                                                                                              IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                                                                  RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                    END IF;
                                                                                                                                                                                                                                                                                                                                                                                                      v_q := public.ar_normalize(coalesce(p_q, ''));
                                                                                                                                                                                                                                                                                                                                                                                                        RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                          SELECT c.id::text, c.make::text, c.model::text, c.year_from::int, c.year_to::int,
                                                                                                                                                                                                                                                                                                                                                                                                                   c.market::text, c.key_type::text, count(*) OVER()
                                                                                                                                                                                                                                                                                                                                                                                                                     FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                       WHERE v_q = '' OR c.make_norm LIKE '%'||v_q||'%' OR c.model_norm LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                         ORDER BY c.make, c.model, c.year_from DESC
                                                                                                                                                                                                                                                                                                                                                                                                                           LIMIT greatest(1, least(p_limit,100)) OFFSET greatest(0, p_offset);
                                                                                                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: admin_set_technician_status(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_set_technician_status(p_user_id uuid, p_status text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                   BEGIN
                                                                                                                                                                     IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                         RAISE EXCEPTION 'غير مصرّح: يتطلب حساب مدير مع تحقق ثنائي مفعّل.'
                                                                                                                                                                               USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                 END IF;

                                                                                                                                                                                   IF p_status NOT IN ('pending','verified','suspended') THEN
                                                                                                                                                                                       RAISE EXCEPTION 'حالة غير صحيحة: %', p_status
                                                                                                                                                                                             USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                               END IF;

                                                                                                                                                                                                 -- حماية: لا يستطيع المدير إيقاف نفسه فيُغلق النظام على الجميع
                                                                                                                                                                                                   IF p_user_id = (SELECT auth.uid()) THEN
                                                                                                                                                                                                       RAISE EXCEPTION 'لا يمكنك تغيير حالة حسابك بنفسك.'
                                                                                                                                                                                                             USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                               END IF;

                                                                                                                                                                                                                 -- التعديل يمر عبر مُشغّل منع التصعيد ومُشغّل التدقيق تلقائياً
                                                                                                                                                                                                                   UPDATE public.profiles
                                                                                                                                                                                                                     SET status = p_status::public.account_status
                                                                                                                                                                                                                       WHERE id = p_user_id;

                                                                                                                                                                                                                         IF NOT FOUND THEN
                                                                                                                                                                                                                             RAISE EXCEPTION 'لم يُعثر على الحساب.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                               END IF;
                                                                                                                                                                                                                               END;
                                                                                                                                                                                                                               $$;


--
-- Name: admin_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_stats() RETURNS TABLE(metric text, value text, hint text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           IF NOT public.is_super_admin() THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     SELECT 'سجلات السيارات',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              (SELECT count(*)::text FROM public.cars_key_data),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       (SELECT count(DISTINCT make)::text || ' ماركة' FROM public.cars_key_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         UNION ALL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SELECT 'جودة البيانات',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    (SELECT coalesce(round(100.0 * count(*) FILTER (WHERE confidence='high') / nullif(count(*),0))::text, '0') || '%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              FROM public.cars_key_data),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       'نسبة المؤكد من مصدر رسمي'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         UNION ALL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SELECT 'فنيون موثّقون',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    (SELECT count(*)::text FROM public.profiles WHERE status='verified'::public.account_status),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             (SELECT count(*)::text || ' بانتظار الاعتماد' FROM public.profiles WHERE status='pending'::public.account_status)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               UNION ALL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 SELECT 'الورش',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          (SELECT count(*)::text FROM public.workshops),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   (SELECT coalesce(sum(seat_limit),0)::text || ' مقعد إجمالي' FROM public.workshops)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     UNION ALL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SELECT 'عمليات بحث (30 يوماً)',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                (SELECT count(*)::text FROM public.search_misses WHERE created_at > now() - INTERVAL '30 days'),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         (SELECT coalesce(round(100.0 * count(*) FILTER (WHERE hits=0) / nullif(count(*),0))::text,'0') || '% بلا نتيجة'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   FROM public.search_misses WHERE created_at > now() - INTERVAL '30 days')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     UNION ALL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SELECT 'مساهمات الفنيين',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                (SELECT count(*)::text FROM public.contributions),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         (SELECT count(*)::text || ' قيد المراجعة' FROM public.contributions WHERE status='pending'::public.contrib_status);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         $$;


--
-- Name: admin_undo_review(bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_undo_review(p_id bigint) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 c   public.contributions%ROWTYPE;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   msg TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RAISE EXCEPTION 'غير مصرّح: يتطلب مديراً مع تحقق ثنائي.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   SELECT * INTO c FROM public.contributions WHERE id = p_id;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     IF NOT FOUND THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RAISE EXCEPTION 'المساهمة غير موجودة.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             IF c.status = 'pending'::public.contrib_status THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 RAISE EXCEPTION 'هذه المساهمة لم تُراجَع بعد.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     IF c.status = 'rejected'::public.contrib_status THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         msg := 'أُعيدت المساهمة إلى قائمة المراجعة.';

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ELSIF c.kind = 'new' THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               -- نحذف السجل الذي أُنشئ وصوره
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   IF c.applied_car_id IS NOT NULL THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         DELETE FROM public.car_images WHERE car_id = c.applied_car_id;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               DELETE FROM public.cars_key_data WHERE id::text = c.applied_car_id;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     msg := 'حُذف السجل المُضاف وأُعيدت المساهمة للمراجعة.';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ELSE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               msg := 'أُعيدت المساهمة للمراجعة (لم يُعثر على السجل المُضاف).';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ELSE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         -- تصحيح: نعيد القيم من اللقطة
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             IF c.prev_data IS NULL THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RAISE EXCEPTION 'لا توجد لقطة للقيم السابقة — هذه مساهمة اعتُمدت قبل تفعيل التراجع، ولا يمكن استرجاعها آلياً.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   UPDATE public.cars_key_data k SET
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         transponder_type     = c.prev_data ->> 'transponder_type',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               key_blade            = c.prev_data ->> 'key_blade',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     remote_frequency     = c.prev_data ->> 'remote_frequency',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           programming_details  = c.prev_data ->> 'programming_details',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 eeprom_location      = c.prev_data ->> 'eeprom_location',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       oem_part_number      = c.prev_data ->> 'oem_part_number',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             special_requirements = c.prev_data ->> 'special_requirements',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   execution_steps      = c.prev_data ->> 'execution_steps',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         warnings_notes       = c.prev_data ->> 'warnings_notes',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               source_note          = c.prev_data ->> 'source_note'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   WHERE k.id::text = c.applied_car_id;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       -- نحذف الصور التي أضافتها هذه المساهمة فقط
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           DELETE FROM public.car_images
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WHERE car_id = c.applied_car_id AND added_by = c.submitted_by AND sort_order >= 1000;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   msg := 'استُرجعت القيم السابقة وأُعيدت المساهمة للمراجعة.';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       UPDATE public.contributions
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         SET status = 'pending'::public.contrib_status,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               reviewed_by = NULL, reviewed_at = NULL, review_note = NULL,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     applied_car_id = NULL, prev_data = NULL
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       WHERE id = p_id;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RETURN msg;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         $$;


--
-- Name: admin_update_workshop(uuid, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_update_workshop(p_id uuid, p_seats integer DEFAULT NULL::integer, p_status text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       IF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           RAISE EXCEPTION 'غير مصرّح.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF p_status IS NOT NULL AND p_status NOT IN ('active','suspended') THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RAISE EXCEPTION 'حالة غير صحيحة.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       UPDATE public.workshops
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         SET seat_limit = coalesce(greatest(1, least(p_seats,200)), seat_limit),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               status     = coalesce(p_status, status)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 WHERE id = p_id;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   IF NOT FOUND THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       RAISE EXCEPTION 'الورشة غير موجودة.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           RETURN 'تم التحديث.';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: car_images_for(text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.car_images_for(p_ids text[]) RETURNS TABLE(car_id text, url text, kind text, caption text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                            BEGIN
                                              -- الصور محتوى فني: للموثّقين فقط، كأكواد Lishi وخطوات البرمجة
                                                IF NOT public.is_verified_locksmith() THEN
                                                    RETURN;
                                                      END IF;

                                                        RETURN QUERY
                                                          SELECT i.car_id, i.url::text, i.kind::text, i.caption::text
                                                            FROM public.car_images i
                                                              WHERE i.car_id = ANY(p_ids)
                                                                ORDER BY i.car_id, i.sort_order, i.id;
                                                                END;
                                                                $$;


--
-- Name: cleanup_rate_limit_events(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_rate_limit_events() RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DELETE FROM public.rate_limit_events WHERE created_at < now() - INTERVAL '1 day';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       $$;


--
-- Name: cleanup_search_log(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cleanup_search_log() RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     DELETE FROM public.search_misses WHERE created_at < now() - INTERVAL '180 days';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     $$;


--
-- Name: enforce_rate_limit(text, integer, interval); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.enforce_rate_limit(p_action text, p_limit integer, p_window interval) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                         DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                           v_actor TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                             v_count INT;
                                                                                                                                                                                                                                                                                                                                                                                                                                             BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                               v_actor := public.actor_fingerprint();

                                                                                                                                                                                                                                                                                                                                                                                                                                                 SELECT count(*) INTO v_count
                                                                                                                                                                                                                                                                                                                                                                                                                                                   FROM public.rate_limit_events e
                                                                                                                                                                                                                                                                                                                                                                                                                                                     WHERE e.actor_key = v_actor
                                                                                                                                                                                                                                                                                                                                                                                                                                                         AND e.action    = p_action
                                                                                                                                                                                                                                                                                                                                                                                                                                                             AND e.created_at > now() - p_window;

                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF v_count >= p_limit THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RAISE EXCEPTION
                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'تم تجاوز الحد المسموح من الطلبات. حاول مرة أخرى بعد قليل.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                               USING ERRCODE = 'too_many_connections';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   INSERT INTO public.rate_limit_events (actor_key, action)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     VALUES (v_actor, p_action);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     $$;


--
-- Name: get_pepper(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_pepper(p_name text) RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                        DECLARE
                                                                                          v_secret TEXT;
                                                                                          BEGIN
                                                                                            SELECT s.decrypted_secret INTO v_secret
                                                                                              FROM vault.decrypted_secrets s
                                                                                                WHERE s.name = p_name;

                                                                                                  IF v_secret IS NULL OR length(v_secret) < 32 THEN
                                                                                                      RAISE EXCEPTION 'الملح الأمني غير مضبوط. نفّذ ملف set_pepper_vault.sql أولاً.'
                                                                                                            USING ERRCODE = 'config_file_error';
                                                                                                              END IF;

                                                                                                                RETURN v_secret;
                                                                                                                END;
                                                                                                                $$;


--
-- Name: guard_profile_privileges(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_profile_privileges() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                            BEGIN
                              IF (NEW.role IS DISTINCT FROM OLD.role)
                                   OR (NEW.status IS DISTINCT FROM OLD.status)
                                        OR (NEW.locked_until IS DISTINCT FROM OLD.locked_until)
                                             OR (NEW.mfa_required IS DISTINCT FROM OLD.mfa_required)
                                                  OR (NEW.workshop_id IS DISTINCT FROM OLD.workshop_id)
                                                       OR (NEW.workshop_role IS DISTINCT FROM OLD.workshop_role)
                                                         THEN
                                                             IF coalesce(current_setting('app.workshop_op', true), '') = 'on' THEN
                                                                   NULL;
                                                                       ELSIF NOT (public.is_super_admin() AND public.has_mfa()) THEN
                                                                             RAISE EXCEPTION
                                                                                     'غير مسموح بتغيير الصلاحيات. يتطلب حساب مدير مع تحقق ثنائي مفعّل.'
                                                                                             USING ERRCODE = 'insufficient_privilege';
                                                                                                 END IF;
                                                                                                   END IF;
                                                                                                     RETURN NEW;
                                                                                                     END;
                                                                                                     $$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
DECLARE
  v_meta    JSONB;
    v_license TEXT;
      v_pepper  TEXT;
      BEGIN
        v_meta    := coalesce(NEW.raw_user_meta_data, '{}'::jsonb);
          v_license := nullif(btrim(coalesce(v_meta ->> 'license_ref','')), '');
            v_pepper  := coalesce(current_setting('app.vin_pepper', true), 'autokey-default-pepper');

              INSERT INTO public.profiles (
                  id, role, status, display_name, workshop_name, city, license_ref_hash
                    )
                      VALUES (
                          NEW.id,
                              'locksmith'::public.app_role,        -- ثابت
                                  'pending'::public.account_status,    -- ثابت — لا وصول حتى الاعتماد
                                      nullif(btrim(coalesce(v_meta ->> 'display_name','')), ''),
                                          nullif(btrim(coalesce(v_meta ->> 'workshop_name','')), ''),
                                              nullif(btrim(coalesce(v_meta ->> 'city','')), ''),
                                                  CASE WHEN v_license IS NULL THEN NULL
                                                           ELSE encode(sha256(convert_to(v_pepper || ':' || v_license || ':' || v_pepper, 'UTF8')), 'hex')
                                                               END
                                                                 )
                                                                   ON CONFLICT (id) DO NOTHING;   -- يحمي الحسابات الموجودة مسبقاً

                                                                     RETURN NEW;
                                                                     END;
                                                                     $$;


--
-- Name: has_mfa(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_mfa() RETURNS boolean
    LANGUAGE sql STABLE
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                        SELECT coalesce((SELECT auth.jwt() ->> 'aal'), 'aal1') = 'aal2';
                                                                                                                                                                                                                                                        $$;


--
-- Name: is_super_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_super_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                            SELECT EXISTS (
                                                                                                                                                                                                SELECT 1 FROM public.profiles p
                                                                                                                                                                                                    WHERE p.id = (SELECT auth.uid())
                                                                                                                                                                                                          AND p.role   = 'super_admin'::public.app_role
                                                                                                                                                                                                                AND p.status = 'verified'::public.account_status
                                                                                                                                                                                                                      AND (p.locked_until IS NULL OR p.locked_until < now())
                                                                                                                                                                                                                        );
                                                                                                                                                                                                                        $$;


--
-- Name: is_verified_locksmith(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_verified_locksmith() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                       SELECT EXISTS (
                                                                                                           SELECT 1
                                                                                                               FROM public.profiles p
                                                                                                                   LEFT JOIN public.workshops w ON w.id = p.workshop_id
                                                                                                                       WHERE p.id = (SELECT auth.uid())
                                                                                                                             AND p.role IN ('locksmith'::public.app_role, 'super_admin'::public.app_role)
                                                                                                                                   AND p.status = 'verified'::public.account_status
                                                                                                                                         AND (p.locked_until IS NULL OR p.locked_until < now())
                                                                                                                                               AND (p.workshop_id IS NULL OR w.status = 'active')
                                                                                                                                                 );
                                                                                                                                                 $$;


--
-- Name: is_workshop_owner(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_workshop_owner() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                   SELECT EXISTS (
                                                                                                                                                       SELECT 1 FROM public.profiles p
                                                                                                                                                           JOIN public.workshops w ON w.id = p.workshop_id
                                                                                                                                                               WHERE p.id = (SELECT auth.uid())
                                                                                                                                                                     AND p.workshop_role = 'owner'
                                                                                                                                                                           AND p.status = 'verified'::public.account_status
                                                                                                                                                                                 AND w.status = 'active'
                                                                                                                                                                                   );
                                                                                                                                                                                   $$;


--
-- Name: list_lishi_tools(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_lishi_tools() RETURNS TABLE(tool_name text, blade_code text, supported_cars text, cut_positions text, pick_direction text, notes text, is_full_access boolean)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                            DECLARE
                                              v_full BOOLEAN;
                                              BEGIN
                                                v_full := public.is_verified_locksmith();

                                                  RETURN QUERY
                                                    SELECT
                                                        t.tool_name::text,
                                                            t.blade_code::text,
                                                                t.supported_cars::text,
                                                                    CASE WHEN v_full THEN t.cut_positions::text  ELSE NULL END,
                                                                        CASE WHEN v_full THEN t.pick_direction::text ELSE NULL END,
                                                                            CASE WHEN v_full THEN t.notes::text          ELSE NULL END,
                                                                                v_full
                                                                                  FROM public.lishi_tools t
                                                                                    ORDER BY t.tool_name;
                                                                                    END;
                                                                                    $$;


--
-- Name: list_makes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_makes() RETURNS TABLE(value text, label text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                  SELECT c.make_base,
                                                                                                                                                                                                                                                                                                                                                                                                                           (array_agg(c.make ORDER BY length(c.make) DESC, c.make))[1]::text
                                                                                                                                                                                                                                                                                                                                                                                                                             FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                               WHERE c.make_base <> ''
                                                                                                                                                                                                                                                                                                                                                                                                                                 GROUP BY c.make_base
                                                                                                                                                                                                                                                                                                                                                                                                                                   ORDER BY 2;
                                                                                                                                                                                                                                                                                                                                                                                                                                   $$;


--
-- Name: list_models(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_models(p_make text) RETURNS TABLE(value text, label text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                     SELECT c.model_base,
                                                                                                                                                                                                                                                                                                                                                                                                                                              (array_agg(c.model ORDER BY length(c.model) DESC, c.model))[1]::text
                                                                                                                                                                                                                                                                                                                                                                                                                                                FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                  WHERE c.make_base = public.ar_base(p_make)
                                                                                                                                                                                                                                                                                                                                                                                                                                                      AND c.model_base <> ''
                                                                                                                                                                                                                                                                                                                                                                                                                                                        GROUP BY c.model_base
                                                                                                                                                                                                                                                                                                                                                                                                                                                          ORDER BY 2;
                                                                                                                                                                                                                                                                                                                                                                                                                                                          $$;


--
-- Name: list_years(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_years(p_make text, p_model text) RETURNS TABLE(year integer)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                            SELECT DISTINCT gs::int
                                                                                                                                                                                                                                                                                                                                                                                                                                                              FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                CROSS JOIN LATERAL generate_series(c.year_from::int, c.year_to::int) AS gs
                                                                                                                                                                                                                                                                                                                                                                                                                                                                  WHERE c.make_base = public.ar_base(p_make)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      AND c.model_base = public.ar_base(p_model)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ORDER BY 1;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                        $$;


--
-- Name: log_search(text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_search(p_query text, p_hits integer) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           DECLARE v_q TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             v_q := public.ar_base(coalesce(p_query,''));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF length(v_q) < 2 THEN RETURN; END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 INSERT INTO public.search_misses (query_norm, hits) VALUES (v_q, coalesce(p_hits,0));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 EXCEPTION WHEN OTHERS THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   RETURN;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   $$;


--
-- Name: log_search_miss(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_search_miss(p_query text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                   DECLARE v_q TEXT;
                                                                                                                                                   BEGIN
                                                                                                                                                     v_q := public.ar_base(coalesce(p_query,''));
                                                                                                                                                       IF length(v_q) < 2 THEN RETURN; END IF;
                                                                                                                                                         INSERT INTO public.search_misses (query_norm, hits) VALUES (v_q, 0);
                                                                                                                                                         EXCEPTION WHEN OTHERS THEN
                                                                                                                                                           RETURN;
                                                                                                                                                           END;
                                                                                                                                                           $$;


--
-- Name: my_access_status(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_access_status() RETURNS TABLE(role text, status text, display_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                 SELECT p.role::text, p.status::text, p.display_name::text
                                                                                                                                                                                                                                   FROM public.profiles p
                                                                                                                                                                                                                                     WHERE p.id = (SELECT auth.uid());
                                                                                                                                                                                                                                     $$;


--
-- Name: my_contributions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_contributions() RETURNS TABLE(id bigint, kind text, status text, note text, review_note text, created_at timestamp with time zone, label text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       SELECT c.id, c.kind, c.status::text, c.note, c.review_note, c.created_at,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                coalesce(c.payload ->> 'make','') || ' ' || coalesce(c.payload ->> 'model','')
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  FROM public.contributions c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    WHERE c.submitted_by = (SELECT auth.uid())
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ORDER BY c.created_at DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        LIMIT 50;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        $$;


--
-- Name: my_workshop(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.my_workshop() RETURNS TABLE(id uuid, name text, city text, seat_limit integer, seats_used integer, status text, my_role text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                    SELECT w.id, w.name::text, w.city::text, w.seat_limit,
                                                                                                                                                                                                             (SELECT count(*)::int FROM public.profiles m WHERE m.workshop_id = w.id),
                                                                                                                                                                                                                      w.status::text, p.workshop_role::text
                                                                                                                                                                                                                        FROM public.profiles p
                                                                                                                                                                                                                          JOIN public.workshops w ON w.id = p.workshop_id
                                                                                                                                                                                                                            WHERE p.id = (SELECT auth.uid());
                                                                                                                                                                                                                            $$;


--
-- Name: record_audit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_audit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             v_record_id TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               IF TG_OP = 'DELETE' THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   v_record_id := (to_jsonb(OLD) ->> 'id');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       INSERT INTO public.audit_log (actor_id, action, table_name, record_id, old_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           VALUES ((SELECT auth.uid()), TG_OP, TG_TABLE_NAME, v_record_id, to_jsonb(OLD));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RETURN OLD;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ELSE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     v_record_id := (to_jsonb(NEW) ->> 'id');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         INSERT INTO public.audit_log (actor_id, action, table_name, record_id, old_data, new_data)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             VALUES (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   (SELECT auth.uid()),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         TG_OP,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               TG_TABLE_NAME,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     v_record_id,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 to_jsonb(NEW)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         RETURN NEW;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           $$;


--
-- Name: search_cars(text, text, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_cars(p_make text, p_model text DEFAULT NULL::text, p_year integer DEFAULT NULL::integer, p_key_type text DEFAULT NULL::text, p_market text DEFAULT NULL::text) RETURNS TABLE(id text, make text, model text, year_from integer, year_to integer, market text, key_type text, transponder_type text, remote_frequency text, fcc_id text, programming_type text, key_blade text, programming_details text, eeprom_location text, oem_part_number text, special_requirements text, execution_steps text, warnings_notes text, board_image_url text, is_full_access boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                              DECLARE
                                                                                                                v_full  BOOLEAN;
                                                                                                                  v_make  TEXT;
                                                                                                                    v_model TEXT;
                                                                                                                    BEGIN
                                                                                                                      IF p_make IS NULL OR length(btrim(p_make)) < 2 THEN
                                                                                                                          RAISE EXCEPTION 'يجب تحديد الماركة للبحث (حرفان على الأقل).'
                                                                                                                                USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                  END IF;

                                                                                                                                    v_full  := public.is_verified_locksmith();
                                                                                                                                      v_make  := public.ar_normalize(p_make);
                                                                                                                                        v_model := public.ar_normalize(coalesce(p_model, ''));

                                                                                                                                          IF v_full THEN
                                                                                                                                              PERFORM public.enforce_rate_limit('search_cars', 300, INTERVAL '5 minutes');
                                                                                                                                                ELSE
                                                                                                                                                    PERFORM public.enforce_rate_limit('search_cars', 40, INTERVAL '5 minutes');
                                                                                                                                                      END IF;

                                                                                                                                                        RETURN QUERY
                                                                                                                                                          SELECT
                                                                                                                                                              c.id::text, c.make::text, c.model::text,
                                                                                                                                                                  c.year_from::int, c.year_to::int, c.market::text, c.key_type::text,
                                                                                                                                                                      c.transponder_type::text, c.remote_frequency::text, c.fcc_id::text,
                                                                                                                                                                          c.programming_type::text,
                                                                                                                                                                              CASE WHEN v_full THEN c.key_blade::text            ELSE NULL END,
                                                                                                                                                                                  CASE WHEN v_full THEN c.programming_details::text  ELSE NULL END,
                                                                                                                                                                                      CASE WHEN v_full THEN c.eeprom_location::text      ELSE NULL END,
                                                                                                                                                                                          CASE WHEN v_full THEN c.oem_part_number::text      ELSE NULL END,
                                                                                                                                                                                              CASE WHEN v_full THEN c.special_requirements::text ELSE NULL END,
                                                                                                                                                                                                  CASE WHEN v_full THEN c.execution_steps::text      ELSE NULL END,
                                                                                                                                                                                                      CASE WHEN v_full THEN c.warnings_notes::text       ELSE NULL END,
                                                                                                                                                                                                          CASE WHEN v_full THEN c.board_image_url::text      ELSE NULL END,
                                                                                                                                                                                                              v_full
                                                                                                                                                                                                                FROM public.cars_key_data c
                                                                                                                                                                                                                  WHERE c.make_norm LIKE '%' || v_make || '%'
                                                                                                                                                                                                                      AND (v_model = '' OR c.model_norm LIKE '%' || v_model || '%')
                                                                                                                                                                                                                          AND (p_year     IS NULL OR (p_year >= c.year_from AND p_year <= c.year_to))
                                                                                                                                                                                                                              AND (p_key_type IS NULL OR p_key_type = '' OR c.key_type = p_key_type)
                                                                                                                                                                                                                                  AND (p_market   IS NULL OR p_market   = '' OR c.market   = p_market)
                                                                                                                                                                                                                                    ORDER BY c.make, c.model, c.year_from DESC
                                                                                                                                                                                                                                      LIMIT 100;
                                                                                                                                                                                                                                      END;
                                                                                                                                                                                                                                      $$;


--
-- Name: search_text(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.search_text(p_query text) RETURNS TABLE(id text, make text, model text, year_from integer, year_to integer, market text, key_type text, transponder_type text, remote_frequency text, fcc_id text, programming_type text, key_blade text, programming_details text, eeprom_location text, oem_part_number text, special_requirements text, execution_steps text, warnings_notes text, board_image_url text, is_full_access boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 DECLARE
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   v_full BOOLEAN;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     v_q    TEXT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       v_n    INT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         v_q := public.ar_normalize(coalesce(p_query, ''));
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           IF length(v_q) < 2 THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               RAISE EXCEPTION 'اكتب حرفين على الأقل للبحث.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   v_full := public.is_verified_locksmith();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     IF v_full THEN PERFORM public.enforce_rate_limit('search_text', 300, INTERVAL '5 minutes');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ELSE           PERFORM public.enforce_rate_limit('search_text', 40,  INTERVAL '5 minutes');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SELECT count(*)::int INTO v_n
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               WHERE c.make_norm  LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    OR c.model_norm LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         OR public.ar_normalize(c.transponder_type) LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              OR public.ar_normalize(c.key_blade)        LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   OR public.ar_normalize(c.fcc_id)           LIKE '%'||v_q||'%';

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     PERFORM public.log_search(p_query, v_n);

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       RETURN QUERY
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         SELECT
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             c.id::text, c.make::text, c.model::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 c.year_from::int, c.year_to::int, c.market::text, c.key_type::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     c.transponder_type::text, c.remote_frequency::text, c.fcc_id::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         c.programming_type::text,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             CASE WHEN v_full THEN c.key_blade::text            ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 CASE WHEN v_full THEN c.programming_details::text  ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     CASE WHEN v_full THEN c.eeprom_location::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         CASE WHEN v_full THEN c.oem_part_number::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             CASE WHEN v_full THEN c.special_requirements::text ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 CASE WHEN v_full THEN c.execution_steps::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     CASE WHEN v_full THEN c.warnings_notes::text       ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         CASE WHEN v_full THEN c.board_image_url::text      ELSE NULL END,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             v_full
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               FROM public.cars_key_data c
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 WHERE c.make_norm  LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      OR c.model_norm LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           OR public.ar_normalize(c.transponder_type) LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                OR public.ar_normalize(c.key_blade)        LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     OR public.ar_normalize(c.fcc_id)           LIKE '%'||v_q||'%'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ORDER BY c.make, c.model, c.year_from DESC
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         LIMIT 50;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         $$;


--
-- Name: submit_contribution(text, jsonb, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.submit_contribution(p_kind text, p_payload jsonb, p_note text DEFAULT NULL::text, p_target_id text DEFAULT NULL::text) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    DECLARE v_id BIGINT;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    BEGIN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      IF NOT public.is_verified_locksmith() THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          RAISE EXCEPTION 'إرسال المساهمات متاح للفنيين الموثّقين فقط.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    IF p_kind NOT IN ('new','correction') THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        RAISE EXCEPTION 'نوع مساهمة غير صحيح.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            IF p_kind = 'correction' AND (p_target_id IS NULL OR p_target_id = '') THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                RAISE EXCEPTION 'التصحيح يحتاج تحديد السجل المقصود.'
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          IF p_kind = 'new' AND (
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 coalesce(btrim(p_payload ->> 'make'), '')  = '' OR
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        coalesce(btrim(p_payload ->> 'model'), '') = '') THEN
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            RAISE EXCEPTION 'الماركة والموديل مطلوبان.' USING ERRCODE = 'invalid_parameter_value';
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              END IF;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                PERFORM public.enforce_rate_limit('submit_contribution', 20, INTERVAL '1 day');

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  INSERT INTO public.contributions (submitted_by, kind, target_id, payload, note)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    VALUES ((SELECT auth.uid()), p_kind, nullif(p_target_id,''), p_payload, nullif(btrim(coalesce(p_note,'')),''))
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      RETURNING id INTO v_id;

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        RETURN v_id;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        END;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        $$;


--
-- Name: sync_all_cars(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_all_cars() RETURNS TABLE(id text, make text, model text, year_from integer, year_to integer, market text, key_type text, transponder_type text, remote_frequency text, fcc_id text, programming_type text, key_blade text, programming_details text, eeprom_location text, oem_part_number text, special_requirements text, execution_steps text, warnings_notes text, board_image_url text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                      BEGIN
                                        IF NOT public.is_verified_locksmith() THEN
                                            RAISE EXCEPTION 'المزامنة للعمل بدون إنترنت متاحة للفنيين الموثّقين فقط.'
                                                  USING ERRCODE = 'insufficient_privilege';
                                                    END IF;

                                                      PERFORM public.enforce_rate_limit('sync_all_cars', 10, INTERVAL '1 day');

                                                        RETURN QUERY
                                                          SELECT
                                                              c.id::text, c.make::text, c.model::text, c.year_from::int, c.year_to::int,
                                                                  c.market::text, c.key_type::text, c.transponder_type::text, c.remote_frequency::text,
                                                                      c.fcc_id::text, c.programming_type::text, c.key_blade::text, c.programming_details::text,
                                                                          c.eeprom_location::text, c.oem_part_number::text, c.special_requirements::text,
                                                                              c.execution_steps::text, c.warnings_notes::text, c.board_image_url::text
                                                                                FROM public.cars_key_data c
                                                                                  ORDER BY c.make, c.model, c.year_from DESC;
                                                                                  END;
                                                                                  $$;


--
-- Name: sync_all_lishi(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_all_lishi() RETURNS TABLE(tool_name text, blade_code text, supported_cars text, cut_positions text, pick_direction text, notes text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                              BEGIN
                                                                                                IF NOT public.is_verified_locksmith() THEN
                                                                                                    RAISE EXCEPTION 'المزامنة متاحة للفنيين الموثّقين فقط.'
                                                                                                          USING ERRCODE = 'insufficient_privilege';
                                                                                                            END IF;

                                                                                                              RETURN QUERY
                                                                                                                SELECT t.tool_name::text, t.blade_code::text, t.supported_cars::text,
                                                                                                                         t.cut_positions::text, t.pick_direction::text, t.notes::text
                                                                                                                           FROM public.lishi_tools t
                                                                                                                             ORDER BY t.tool_name;
                                                                                                                             END;
                                                                                                                             $$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
                                                                                                                                                                                  BEGIN
                                                                                                                                                                                    NEW.updated_at = now();
                                                                                                                                                                                      RETURN NEW;
                                                                                                                                                                                      END;
                                                                                                                                                                                      $$;


--
-- Name: vin_fingerprint(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.vin_fingerprint(p_vin text) RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                DECLARE
                                                                                                                  v_pepper TEXT;
                                                                                                                  BEGIN
                                                                                                                    IF p_vin IS NULL OR length(btrim(p_vin)) = 0 THEN
                                                                                                                        RETURN NULL;
                                                                                                                          END IF;

                                                                                                                            v_pepper := public.get_pepper('autokey_vin_pepper');

                                                                                                                              RETURN encode(
                                                                                                                                  sha256(convert_to(v_pepper || ':' || upper(btrim(p_vin)) || ':' || v_pepper, 'UTF8')),
                                                                                                                                      'hex'
                                                                                                                                        );
                                                                                                                                        END;
                                                                                                                                        $$;


--
-- Name: workshop_add_member(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workshop_add_member(p_email text) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                    DECLARE
                                                                                                                                                                                                                                                                      v_ws    UUID;
                                                                                                                                                                                                                                                                        v_limit INT;
                                                                                                                                                                                                                                                                          v_used  INT;
                                                                                                                                                                                                                                                                            v_uid   UUID;
                                                                                                                                                                                                                                                                              v_cur   UUID;
                                                                                                                                                                                                                                                                              BEGIN
                                                                                                                                                                                                                                                                                IF NOT public.is_workshop_owner() THEN
                                                                                                                                                                                                                                                                                    RAISE EXCEPTION 'هذه العملية لصاحب الورشة فقط.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                      END IF;

                                                                                                                                                                                                                                                                                        SELECT p.workshop_id INTO v_ws FROM public.profiles p WHERE p.id = (SELECT auth.uid());
                                                                                                                                                                                                                                                                                          SELECT w.seat_limit INTO v_limit FROM public.workshops w WHERE w.id = v_ws;
                                                                                                                                                                                                                                                                                            SELECT count(*)::int INTO v_used FROM public.profiles m WHERE m.workshop_id = v_ws;

                                                                                                                                                                                                                                                                                              IF v_used >= v_limit THEN
                                                                                                                                                                                                                                                                                                  RAISE EXCEPTION 'اكتمل عدد المقاعد (%). راسل الإدارة لزيادتها.', v_limit
                                                                                                                                                                                                                                                                                                        USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                          END IF;

                                                                                                                                                                                                                                                                                                            SELECT u.id INTO v_uid FROM auth.users u
                                                                                                                                                                                                                                                                                                              WHERE lower(u.email) = lower(btrim(p_email));

                                                                                                                                                                                                                                                                                                                IF v_uid IS NULL THEN
                                                                                                                                                                                                                                                                                                                    RAISE EXCEPTION 'لا يوجد حساب بهذا البريد. اطلب من الفني التسجيل أولاً.'
                                                                                                                                                                                                                                                                                                                          USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                                            END IF;

                                                                                                                                                                                                                                                                                                                              SELECT p.workshop_id INTO v_cur FROM public.profiles p WHERE p.id = v_uid;
                                                                                                                                                                                                                                                                                                                                IF v_cur IS NOT NULL THEN
                                                                                                                                                                                                                                                                                                                                    RAISE EXCEPTION 'هذا الفني منضم لورشة أخرى بالفعل.' USING ERRCODE = 'unique_violation';
                                                                                                                                                                                                                                                                                                                                      END IF;

                                                                                                                                                                                                                                                                                                                                        PERFORM set_config('app.workshop_op', 'on', true);

                                                                                                                                                                                                                                                                                                                                          UPDATE public.profiles
                                                                                                                                                                                                                                                                                                                                            SET workshop_id   = v_ws,
                                                                                                                                                                                                                                                                                                                                                  workshop_role = 'member',
                                                                                                                                                                                                                                                                                                                                                        role          = 'locksmith'::public.app_role,
                                                                                                                                                                                                                                                                                                                                                              status        = 'verified'::public.account_status
                                                                                                                                                                                                                                                                                                                                                                WHERE id = v_uid;

                                                                                                                                                                                                                                                                                                                                                                  PERFORM set_config('app.workshop_op', '', true);

                                                                                                                                                                                                                                                                                                                                                                    RETURN 'تمت إضافة الفني وتفعيل حسابه.';
                                                                                                                                                                                                                                                                                                                                                                    END;
                                                                                                                                                                                                                                                                                                                                                                    $$;


--
-- Name: workshop_members(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workshop_members() RETURNS TABLE(user_id uuid, email text, display_name text, status text, workshop_role text, created_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                           DECLARE v_ws UUID;
                                                                                                                                                                                                                                           BEGIN
                                                                                                                                                                                                                                             SELECT p.workshop_id INTO v_ws FROM public.profiles p WHERE p.id = (SELECT auth.uid());
                                                                                                                                                                                                                                               IF v_ws IS NULL THEN RETURN; END IF;

                                                                                                                                                                                                                                                 RETURN QUERY
                                                                                                                                                                                                                                                   SELECT m.id, u.email::text, m.display_name::text,
                                                                                                                                                                                                                                                            m.status::text, m.workshop_role::text, m.created_at
                                                                                                                                                                                                                                                              FROM public.profiles m
                                                                                                                                                                                                                                                                JOIN auth.users u ON u.id = m.id
                                                                                                                                                                                                                                                                  WHERE m.workshop_id = v_ws
                                                                                                                                                                                                                                                                    ORDER BY (m.workshop_role = 'owner') DESC, m.created_at;
                                                                                                                                                                                                                                                                    END;
                                                                                                                                                                                                                                                                    $$;


--
-- Name: workshop_remove_member(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.workshop_remove_member(p_user_id uuid) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $$
                                                                                                                                                                                                                                                                                                                                                                    DECLARE v_ws UUID;
                                                                                                                                                                                                                                                                                                                                                                    BEGIN
                                                                                                                                                                                                                                                                                                                                                                      IF NOT public.is_workshop_owner() THEN
                                                                                                                                                                                                                                                                                                                                                                          RAISE EXCEPTION 'هذه العملية لصاحب الورشة فقط.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                            END IF;
                                                                                                                                                                                                                                                                                                                                                                              IF p_user_id = (SELECT auth.uid()) THEN
                                                                                                                                                                                                                                                                                                                                                                                  RAISE EXCEPTION 'لا يمكنك إزالة نفسك من ورشتك.' USING ERRCODE = 'insufficient_privilege';
                                                                                                                                                                                                                                                                                                                                                                                    END IF;

                                                                                                                                                                                                                                                                                                                                                                                      SELECT p.workshop_id INTO v_ws FROM public.profiles p WHERE p.id = (SELECT auth.uid());

                                                                                                                                                                                                                                                                                                                                                                                        PERFORM set_config('app.workshop_op', 'on', true);

                                                                                                                                                                                                                                                                                                                                                                                          UPDATE public.profiles
                                                                                                                                                                                                                                                                                                                                                                                            SET workshop_id = NULL, workshop_role = NULL,
                                                                                                                                                                                                                                                                                                                                                                                                  status = 'pending'::public.account_status
                                                                                                                                                                                                                                                                                                                                                                                                    WHERE id = p_user_id AND workshop_id = v_ws AND workshop_role = 'member';

                                                                                                                                                                                                                                                                                                                                                                                                      PERFORM set_config('app.workshop_op', '', true);

                                                                                                                                                                                                                                                                                                                                                                                                        IF NOT FOUND THEN
                                                                                                                                                                                                                                                                                                                                                                                                            RAISE EXCEPTION 'هذا الفني ليس عضواً في ورشتك.' USING ERRCODE = 'no_data_found';
                                                                                                                                                                                                                                                                                                                                                                                                              END IF;
                                                                                                                                                                                                                                                                                                                                                                                                                RETURN 'تمت إزالة الفني.';
                                                                                                                                                                                                                                                                                                                                                                                                                END;
                                                                                                                                                                                                                                                                                                                                                                                                                $$;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor_id uuid,
    action text NOT NULL,
    table_name text NOT NULL,
    record_id text,
    old_data jsonb,
    new_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: car_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.car_images (
    id bigint NOT NULL,
    car_id text NOT NULL,
    url text NOT NULL,
    kind text DEFAULT 'other'::text NOT NULL,
    caption text,
    sort_order integer DEFAULT 0 NOT NULL,
    added_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT car_images_kind_check CHECK ((kind = ANY (ARRAY['remote'::text, 'board'::text, 'lishi'::text, 'key'::text, 'tool'::text, 'other'::text])))
);


--
-- Name: COLUMN car_images.kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.car_images.kind IS 'remote=الريموت، board=البوردة، lishi=موضع القص، key=المفتاح، tool=الجهاز، other=أخرى';


--
-- Name: car_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.car_images ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.car_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contributions (
    id bigint NOT NULL,
    submitted_by uuid NOT NULL,
    kind text NOT NULL,
    target_id text,
    payload jsonb NOT NULL,
    note text,
    status public.contrib_status DEFAULT 'pending'::public.contrib_status NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_car_id text,
    prev_data jsonb,
    CONSTRAINT contributions_kind_check CHECK ((kind = ANY (ARRAY['new'::text, 'correction'::text])))
);


--
-- Name: contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.contributions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.contributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: lishi_tools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lishi_tools (
    id bigint NOT NULL,
    tool_name text NOT NULL,
    blade_code text NOT NULL,
    supported_cars text NOT NULL,
    cut_positions text,
    pick_direction text,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: lishi_tools_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.lishi_tools ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lishi_tools_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    role public.app_role DEFAULT 'guest'::public.app_role NOT NULL,
    status public.account_status DEFAULT 'pending'::public.account_status NOT NULL,
    display_name text,
    workshop_name text,
    city text,
    license_ref_hash text,
    mfa_required boolean DEFAULT false NOT NULL,
    locked_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    workshop_id uuid,
    workshop_role text,
    CONSTRAINT profiles_workshop_role_check CHECK ((workshop_role = ANY (ARRAY['owner'::text, 'member'::text])))
);


--
-- Name: TABLE profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.profiles IS 'ملفات الفنيين والصلاحيات. كلمات المرور في auth.users (bcrypt عبر Supabase Auth)';


--
-- Name: COLUMN profiles.license_ref_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.license_ref_hash IS 'بصمة مشفّرة لرقم الرخصة — لا يُخزَّن الرقم الصريح أبداً';


--
-- Name: rate_limit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limit_events (
    id bigint NOT NULL,
    actor_key text NOT NULL,
    action text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rate_limit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rate_limit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: search_misses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_misses (
    id bigint NOT NULL,
    query_norm text NOT NULL,
    hits integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE search_misses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.search_misses IS 'عمليات بحث لم تُرجع نتائج — لتحديد أولويات إضافة البيانات. بلا هوية.';


--
-- Name: search_misses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.search_misses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.search_misses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: work_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    technician_id uuid NOT NULL,
    car_ref text,
    job_type text,
    vin_fingerprint text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT work_log_vin_fingerprint_check CHECK (((vin_fingerprint IS NULL) OR (vin_fingerprint ~ '^[0-9a-f]{64}$'::text)))
);


--
-- Name: TABLE work_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.work_log IS 'سجل أعمال الفني — بدون لوحات وبدون VIN صريح، لمنع تتبّع تحركات الفنيين';


--
-- Name: COLUMN work_log.vin_fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.work_log.vin_fingerprint IS 'بصمة HMAC-SHA256 للـ VIN — لا يمكن عكسها لاستخراج الرقم الأصلي';


--
-- Name: workshops; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workshops (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    city text,
    owner_id uuid,
    seat_limit integer DEFAULT 3 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workshops_seat_limit_check CHECK (((seat_limit >= 1) AND (seat_limit <= 200))),
    CONSTRAINT workshops_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text])))
);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, actor_id, action, table_name, record_id, old_data, new_data, created_at) FROM stdin;
1	\N	INSERT	profiles	796b0d23-5e2b-4a05-a18d-311eb39c6c11	\N	{"id": "796b0d23-5e2b-4a05-a18d-311eb39c6c11", "city": null, "role": "super_admin", "status": "verified", "created_at": "2026-09-02T23:51:39.757992+00:00", "updated_at": "2026-09-02T23:51:39.757992+00:00", "display_name": null, "locked_until": null, "mfa_required": true, "workshop_name": null, "license_ref_hash": null}	2026-09-02 23:51:39.757992+00
2	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	73075312-877b-4b6d-bcaf-7b3ddd358350	{"id": "73075312-877b-4b6d-bcaf-7b3ddd358350", "make": "تويوتا", "model": "كامري", "fcc_id": null, "market": "gcc", "year_to": 2002, "key_type": null, "image_url": null, "key_blade": "لِيشي: TOY43", "year_from": 2001, "created_at": "2026-08-31T08:34:02.653922+00:00", "warnings_notes": null, "board_image_url": null, "eeprom_location": "جهاز ايمو خلف المسجل", "execution_steps": null, "oem_part_number": null, "programming_type": "manual", "remote_frequency": "", "transponder_type": "ID 4C/000000", "programming_details": "تحول شريحه اصفار", "special_requirements": null}	{"id": "73075312-877b-4b6d-bcaf-7b3ddd358350", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2002, "key_type": null, "image_url": null, "key_blade": "لِيشي: TOY43", "year_from": 2001, "created_at": "2026-08-31T08:34:02.653922+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "جهاز ايمو خلف المسجل", "execution_steps": "", "oem_part_number": "", "programming_type": "manual", "remote_frequency": "", "transponder_type": "ID 4C/000000", "programming_details": "تحول شريحه اصفار", "special_requirements": ""}	2026-09-03 00:08:22.964034+00
3	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	fce6f926-aff3-4cbc-a388-c095e5b4c283	{"id": "fce6f926-aff3-4cbc-a388-c095e5b4c283", "make": "نيسان", "model": "ألتيما (Altima)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "NSN14 / لِيشي: Lishi NSN14", "year_from": 2019, "created_at": "2026-09-02T22:26:01.958576+00:00", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC Specs)", "transponder_type": "Hitag AES (ID4A / NCF29A1M)", "programming_details": "عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR", "special_requirements": null}	{"id": "fce6f926-aff3-4cbc-a388-c095e5b4c283", "make": "نيسان", "model": "ألتيما (Altima)", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": "smart", "image_url": null, "key_blade": "NSN14 / لِيشي: Lishi NSN14", "year_from": 2019, "created_at": "2026-09-02T22:26:01.958576+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC Specs)", "transponder_type": "Hitag AES (ID4A / NCF29A1M)", "programming_details": "عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR", "special_requirements": ""}	2026-09-03 00:09:20.753057+00
4	796b0d23-5e2b-4a05-a18d-311eb39c6c11	INSERT	cars_key_data	189f9aca-5bd5-4d27-8618-5e4428682eeb	\N	{"id": "189f9aca-5bd5-4d27-8618-5e4428682eeb", "make": "هيونداي", "model": "اكسنت", "fcc_id": "", "market": "gcc", "year_to": 2006, "key_type": "blade", "image_url": null, "key_blade": "", "year_from": 2001, "created_at": "2026-09-03T00:15:00.587947+00:00", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "manual", "remote_frequency": "", "transponder_type": "46", "programming_details": "", "special_requirements": ""}	2026-09-03 00:15:00.587947+00
5	\N	INSERT	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	\N	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "pending", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-03T20:15:34.372103+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-03 20:15:34.372103+00
6	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "pending", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-03T20:15:34.372103+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "verified", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:16:18.323138+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-04 05:16:18.323138+00
7	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "verified", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:16:18.323138+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "pending", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:51:25.18278+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-04 05:51:25.18278+00
8	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "pending", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:51:25.18278+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "verified", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:51:28.870526+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-04 05:51:28.870526+00
9	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	a672f727-345b-4444-b181-c54ef3787d74	{"id": "a672f727-345b-4444-b181-c54ef3787d74", "make": "تويوتا", "model": "كامري (Camry)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2018, "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "كامري", "model_norm": "كامري (camry)", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (مواصفات خليجية GCC)", "transponder_type": "Texas Crypto 8A (Page 1: A8 / A9 / AA)", "programming_details": "عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus", "special_requirements": null}	{"id": "a672f727-345b-4444-b181-c54ef3787d74", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2018, "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "كامري", "model_norm": "كامري", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (مواصفات خليجية GCC)", "transponder_type": "Texas Crypto 8A (Page 1: A8 / A9 / AA)", "programming_details": "عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus", "special_requirements": ""}	2026-09-04 07:46:29.99878+00
10	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	429ed3c4-5ff1-423d-b221-cc0ee4ff2b03	{"id": "429ed3c4-5ff1-423d-b221-cc0ee4ff2b03", "make": "تويوتا", "model": "كامري (Camry)", "fcc_id": null, "market": "gcc", "year_to": 2017, "key_type": null, "image_url": null, "key_blade": "TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2012, "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "كامري", "model_norm": "كامري (camry)", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz ASK", "transponder_type": "4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)", "programming_details": "برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR", "special_requirements": null}	{"id": "429ed3c4-5ff1-423d-b221-cc0ee4ff2b03", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2017, "key_type": null, "image_url": null, "key_blade": "TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2012, "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "كامري", "model_norm": "كامري", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz ASK", "transponder_type": "4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)", "programming_details": "برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR", "special_requirements": ""}	2026-09-04 07:46:48.803669+00
11	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	bddc93bd-7823-4831-882d-9366eab3e050	{"id": "bddc93bd-7823-4831-882d-9366eab3e050", "make": "تويوتا", "model": "كامري (Camry)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": "remote", "image_url": null, "key_blade": "TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2018, "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "كامري", "model_norm": "كامري (camry)", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (مواصفات خليجية GCC)", "transponder_type": "Texas Crypto 8A (Page 1: A8 / A9 / AA)", "programming_details": "عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus", "special_requirements": null}	{"id": "bddc93bd-7823-4831-882d-9366eab3e050", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": "remote", "image_url": null, "key_blade": "TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2018, "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "كامري", "model_norm": "كامري", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (مواصفات خليجية GCC)", "transponder_type": "Texas Crypto 8A (Page 1: A8 / A9 / AA)", "programming_details": "عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus", "special_requirements": ""}	2026-09-04 07:47:06.300745+00
12	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	8d55a472-2057-4347-bee4-c79c577c50ae	{"id": "8d55a472-2057-4347-bee4-c79c577c50ae", "make": "تويوتا", "model": "كامري (Camry)", "fcc_id": null, "market": "gcc", "year_to": 2017, "key_type": "remote", "image_url": null, "key_blade": "TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2012, "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "كامري", "model_norm": "كامري (camry)", "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz ASK", "transponder_type": "4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)", "programming_details": "برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR", "special_requirements": null}	{"id": "8d55a472-2057-4347-bee4-c79c577c50ae", "make": "تويوتا", "model": "كامري", "fcc_id": "", "market": "gcc", "year_to": 2017, "key_type": "remote", "image_url": null, "key_blade": "TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)", "make_base": "تويوتا", "make_norm": "تويوتا", "year_from": 2012, "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "كامري", "model_norm": "كامري", "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz ASK", "transponder_type": "4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)", "programming_details": "برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR", "special_requirements": ""}	2026-09-04 07:47:20.636702+00
13	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	ec202f86-b13f-4ffe-b695-ed393a4c85d7	{"id": "ec202f86-b13f-4ffe-b695-ed393a4c85d7", "make": "هيونداي", "model": "إلنترا (Elantra)", "fcc_id": null, "market": "gcc", "year_to": 2020, "key_type": "remote", "image_url": null, "key_blade": "HY22 / لِيشي: Lishi HY22", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2016, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "النترا", "model_norm": "النترا (elantra)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "ID47 Hitag3", "programming_details": "منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR", "special_requirements": null}	{"id": "ec202f86-b13f-4ffe-b695-ed393a4c85d7", "make": "هيونداي", "model": "إلنترا", "fcc_id": "", "market": "gcc", "year_to": 2020, "key_type": "remote", "image_url": null, "key_blade": "HY22 / لِيشي: Lishi HY22", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2016, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "النترا", "model_norm": "النترا", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "ID47 Hitag3", "programming_details": "منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR", "special_requirements": ""}	2026-09-04 10:23:56.387162+00
14	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	ff888159-4d1b-465e-90bf-0c01bfac5f5f	{"id": "ff888159-4d1b-465e-90bf-0c01bfac5f5f", "make": "هيونداي", "model": "إلنترا (Elantra)", "fcc_id": null, "market": "gcc", "year_to": 2020, "key_type": null, "image_url": null, "key_blade": "HY22 / لِيشي: Lishi HY22", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2016, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "النترا", "model_norm": "النترا (elantra)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "ID47 Hitag3", "programming_details": "منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR", "special_requirements": null}	{"id": "ff888159-4d1b-465e-90bf-0c01bfac5f5f", "make": "هيونداي", "model": "إلنترا", "fcc_id": "", "market": "gcc", "year_to": 2020, "key_type": null, "image_url": null, "key_blade": "HY22 / لِيشي: Lishi HY22", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2016, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "النترا", "model_norm": "النترا", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "ID47 Hitag3", "programming_details": "منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR", "special_requirements": ""}	2026-09-04 10:24:08.299147+00
15	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	f30bbb58-c435-4669-a8e0-48aebb103e43	{"id": "f30bbb58-c435-4669-a8e0-48aebb103e43", "make": "هيونداي", "model": "سوناتا (Sonata)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": "remote", "image_url": null, "key_blade": "HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2020, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "سوناتا", "model_norm": "سوناتا (sonata)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "Hitag AES / NCF29A1X (ID47)", "programming_details": "برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor", "special_requirements": null}	{"id": "f30bbb58-c435-4669-a8e0-48aebb103e43", "make": "هيونداي", "model": "سوناتا", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": "remote", "image_url": null, "key_blade": "HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2020, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "سوناتا", "model_norm": "سوناتا", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "Hitag AES / NCF29A1X (ID47)", "programming_details": "برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor", "special_requirements": ""}	2026-09-04 10:24:27.366982+00
16	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	f3dcd12b-be35-4557-8d2e-44c108a209f2	{"id": "f3dcd12b-be35-4557-8d2e-44c108a209f2", "make": "هيونداي", "model": "سوناتا (Sonata)", "fcc_id": null, "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2020, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "سوناتا", "model_norm": "سوناتا (sonata)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "Hitag AES / NCF29A1X (ID47)", "programming_details": "برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor", "special_requirements": null}	{"id": "f3dcd12b-be35-4557-8d2e-44c108a209f2", "make": "هيونداي", "model": "سوناتا", "fcc_id": "", "market": "gcc", "year_to": 2024, "key_type": null, "image_url": null, "key_blade": "HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)", "make_base": "هيونداي", "make_norm": "هيونداي", "year_from": 2020, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "سوناتا", "model_norm": "سوناتا", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK", "transponder_type": "Hitag AES / NCF29A1X (ID47)", "programming_details": "برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor", "special_requirements": ""}	2026-09-04 10:24:36.940412+00
17	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "verified", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T05:51:28.870526+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "suspended", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T10:58:44.847158+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-04 10:58:44.847158+00
18	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	profiles	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "suspended", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T10:58:44.847158+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	{"id": "515ed2c9-b248-4b54-b8fa-0a6ee5bf3143", "city": "بحره", "role": "locksmith", "status": "verified", "created_at": "2026-09-03T20:15:34.372103+00:00", "updated_at": "2026-09-04T11:47:23.361059+00:00", "display_name": "نسيم احمد", "locked_until": null, "mfa_required": false, "workshop_name": "المفالح الذهبي", "license_ref_hash": "e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744"}	2026-09-04 11:47:23.361059+00
19	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	6ca3e637-32c0-469c-8503-b9992f5b1148	{"id": "6ca3e637-32c0-469c-8503-b9992f5b1148", "make": "فورد", "model": "تورس (Taurus)", "fcc_id": null, "market": "gcc", "year_to": 2023, "key_type": "remote", "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "تورس", "model_norm": "تورس (taurus)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "Hitag Pro / ID49 / Texas 128-Bit", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": null}	{"id": "6ca3e637-32c0-469c-8503-b9992f5b1148", "make": "فورد", "model": "تورس (Taurus)", "fcc_id": null, "market": "gcc", "year_to": 2023, "key_type": "remote", "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "تورس", "model_norm": "تورس (taurus)", "data_source": null, "source_note": " | تصحيح من: nasemm56@hotmail.com", "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "83ford80bits", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": null}	2026-09-04 18:08:55.625955+00
20	796b0d23-5e2b-4a05-a18d-311eb39c6c11	INSERT	cars_key_data	a01a7e04-08c5-4123-9599-da53989d5037	\N	{"id": "a01a7e04-08c5-4123-9599-da53989d5037", "make": "فورد", "model": "تورس", "fcc_id": null, "market": "gcc", "year_to": 2015, "key_type": "smart", "image_url": null, "key_blade": "FO38", "make_base": "فورد", "make_norm": "فورد", "year_from": 2013, "confidence": "medium", "created_at": "2026-09-05T02:28:30.333612+00:00", "model_base": "تورس", "model_norm": "تورس", "data_source": "مساهمة فني: نسيم احمد", "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": null, "execution_steps": null, "oem_part_number": null, "programming_type": "manual", "remote_frequency": "433", "transponder_type": "ID46 (Hitag 2)", "programming_details": null, "special_requirements": null}	2026-09-05 02:28:30.333612+00
21	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	6ca3e637-32c0-469c-8503-b9992f5b1148	{"id": "6ca3e637-32c0-469c-8503-b9992f5b1148", "make": "فورد", "model": "تورس (Taurus)", "fcc_id": null, "market": "gcc", "year_to": 2023, "key_type": "remote", "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "تورس", "model_norm": "تورس (taurus)", "data_source": null, "source_note": " | تصحيح من: nasemm56@hotmail.com", "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "83ford80bits", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": null}	{"id": "6ca3e637-32c0-469c-8503-b9992f5b1148", "make": "فورد", "model": "تورس", "fcc_id": "", "market": "gcc", "year_to": 2023, "key_type": "remote", "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T21:54:59.791132+00:00", "model_base": "تورس", "model_norm": "تورس", "data_source": null, "source_note": " | تصحيح من: nasemm56@hotmail.com", "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "83ford80bits", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": ""}	2026-09-05 02:39:06.784041+00
22	796b0d23-5e2b-4a05-a18d-311eb39c6c11	UPDATE	cars_key_data	5c7840d5-e8db-4f60-9588-ce57b75164c2	{"id": "5c7840d5-e8db-4f60-9588-ce57b75164c2", "make": "فورد", "model": "تورس (Taurus)", "fcc_id": null, "market": "gcc", "year_to": 2023, "key_type": null, "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "تورس", "model_norm": "تورس (taurus)", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": null, "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": null, "oem_part_number": null, "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "Hitag Pro / ID49 / Texas 128-Bit", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": null}	{"id": "5c7840d5-e8db-4f60-9588-ce57b75164c2", "make": "فورد", "model": "تورس", "fcc_id": "", "market": "gcc", "year_to": 2023, "key_type": null, "image_url": null, "key_blade": "HU101 / لِيشي: Lishi HU101 (2-in-1)", "make_base": "فورد", "make_norm": "فورد", "year_from": 2015, "confidence": "medium", "created_at": "2026-09-02T22:26:01.958576+00:00", "model_base": "تورس", "model_norm": "تورس", "data_source": null, "source_note": null, "verified_at": null, "warnings_notes": "", "board_image_url": null, "eeprom_location": "جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)", "execution_steps": "", "oem_part_number": "", "programming_type": "obd", "remote_frequency": "433.92 MHz FSK (GCC) / 315 MHz (US)", "transponder_type": "Hitag Pro / ID49 / Texas 128-Bit", "programming_details": "عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR", "special_requirements": ""}	2026-09-05 02:41:01.132931+00
\.


--
-- Data for Name: car_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.car_images (id, car_id, url, kind, caption, sort_order, added_by, created_at) FROM stdin;
1	a841916d-89e8-4fea-957f-f46693b4ef8b	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788269942223_1000112510.jpg	board	صورة البوردة	0	\N	2026-09-05 01:38:54.622305+00
2	8fdb9dae-52d4-47db-a032-5a77126b711e	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788189589921_1000112017.jpg	board	صورة البوردة	0	\N	2026-09-05 01:38:54.622305+00
3	91ad8f7e-6253-42ad-92a7-c15dcba312a7	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788270104611_1000112511.jpg	board	صورة البوردة	0	\N	2026-09-05 01:38:54.622305+00
4	a01a7e04-08c5-4123-9599-da53989d5037	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/contrib/1788575007796_1000113953.jpg	remote	من: نسيم احمد	1000	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	2026-09-05 02:28:30.333612+00
5	a01a7e04-08c5-4123-9599-da53989d5037	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/contrib/1788575153973_1000114201.jpg	key	من: نسيم احمد	1001	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	2026-09-05 02:28:30.333612+00
\.


--
-- Data for Name: cars_key_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cars_key_data (id, created_at, make, model, year_from, year_to, market, transponder_type, key_blade, remote_frequency, programming_type, programming_details, eeprom_location, image_url, board_image_url, fcc_id, key_type, oem_part_number, special_requirements, execution_steps, warnings_notes, data_source, confidence, verified_at, source_note) FROM stdin;
189f9aca-5bd5-4d27-8618-5e4428682eeb	2026-09-03 00:15:00.587947+00	هيونداي	اكسنت	2001	2006	gcc	46			manual			\N	\N		blade					\N	medium	\N	\N
f6a25fc0-ce56-4562-9c43-ab5fa0b6dce8	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2003	2006	gcc	4C	لِيشي: TOY43		obd	OBD مطلوب لمعظم الحالات (Smart Pro / AutoProPad / Tango)	داخل كمبيوتر المحرك (ECU) — يُقرأ عبر جهاز متخصص عند فقد جميع المفاتيح	\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
8b9a737a-2699-45b7-a577-36ef951518b4	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2007	2012	gcc	Toyota 4D-67-Chip	لِيشي:  TOY43		obd	OBD إلزامي — Smart Pro / AutoProPad		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
73075312-877b-4b6d-bcaf-7b3ddd358350	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2001	2002	gcc	ID 4C/000000	لِيشي: TOY43		manual	تحول شريحه اصفار	جهاز ايمو خلف المسجل	\N	\N		\N					\N	medium	\N	\N
12d44165-a6ee-40a5-bc02-a7e42a77c419	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2018	2024	us	Toyota H-Chip / Smart Key (AES)	مفتاح ذكي بدون شفرة تقليدية (Emergency Key: TOY44D)	315 MHz	obd	OBD + تصريح أونلاين من تويوتا (Toyota FTZ / TIS Techstream) في أغلب الحالات	Smart Key ECU خلف لوحة القيادة اليمنى	\N	\N	\N	smart	\N	\N	\N	\N	\N	medium	\N	\N
95973140-8f4c-4eb3-aadf-8215f71edd37	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2007	2011	us	Toyota G-Chip (128-bit)	TOY44 / لِيشي: TOY44	315 MHz	obd	OBD إلزامي (لا توجد طريقة يدوية) — Smart Pro / AutoProPad	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
3b6b69e6-6249-4126-902c-0454a319edfb	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2006	2015	gcc	بدون	TOY43 / لِيشي: TOY43		manual			\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
57c931ea-3017-413d-a63e-c2de535d370b	2026-08-31 09:22:07.170698+00	تويوتا	كورولا	2001	2006	gcc	4C	toy43		manual	فك كمبيوتر	25020	\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
5e4581bf-55bb-414e-99eb-34a511325a08	2026-09-01 13:03:43.657206+00	تويوتا	افلون	0	25	gcc				manual			\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
207bd0d6-44ec-4efa-92da-78020f9d509d	2026-09-01 13:04:11.952317+00	تويوتا	اوريون	0	1	gcc				manual			\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
d268362a-d9c2-44ec-9a7f-dab963fabe5a	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	1999	2005	us	ID46 (PCF7936)	HY15 / لِيشي: HU134	315 MHz	manual	عبر Pin Code محسوب من رقم الهيكل (VIN)	غير مطلوب غالباً — يعتمد على Pin Code وليس EEPROM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
189ce114-0332-406e-9c21-96a85678955f	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2018	2024	gcc	Toyota H-Chip / Smart Key (AES)	مفتاح ذكي بدون شفرة تقليدية (Emergency Key: TOY44D)	433 MHz	obd	OBD + تصريح أونلاين من تويوتا في أغلب الحالات	Smart Key ECU خلف لوحة القيادة اليمنى	\N	\N	\N	smart	\N	\N	\N	\N	\N	medium	\N	\N
8e9162fd-7cde-444b-b38c-764e74f2d192	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2000	2001	us	Toyota 4D-67 (TP08)	TR47 / لِيشي: TOY43	315 MHz	manual	يدوية بمفتاحين سليمين (10 دورات تشغيل/إيقاف) أو عبر جهاز OBD	غير مطلوب عادة — عند فقد كل المفاتيح: قراءة كمبيوتر المحرك عبر جهاز متخصص (Tango/MVP)	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
96b6bfb2-c829-45b1-93cf-05fbe4451ef2	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2002	2006	us	Toyota 4D-67	TR47 / لِيشي: TOY43	315 MHz	obd	OBD مطلوب لمعظم الحالات (Smart Pro / AutoProPad / Tango)	داخل كمبيوتر المحرك (ECU) — يُقرأ عبر جهاز متخصص عند فقد جميع المفاتيح	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
ed4584c3-d5b8-42f2-b1f7-ad25a18430cd	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2012	2017	us	Toyota H-Chip (128-bit AES)	TOY44D — بعض الفئات مفتاح ذكي بدون شفرة	315 MHz	obd	OBD إلزامي، ومفاتيح النظام الذكي تحتاج غالباً اتصال أونلاين بسيرفر تويوتا	BCM / Smart Key ECU — خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
cd962bb2-1955-455e-8085-cb63900ec15a	2026-08-31 08:34:02.653922+00	تويوتا	كامري	2013	2015	gcc	Toyota G-Chip	TOY43	433 MHz	obd	OBD إلزامي، نظام المفتاح الذكي	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
309d3433-9ca6-477d-9276-bc0e755b244a	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	1999	2005	gcc	ID46 (PCF7936)	HY15 / لِيشي: HU134	433 MHz	manual	عبر Pin Code محسوب من رقم الهيكل (VIN)	غير مطلوب غالباً — يعتمد على Pin Code	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
c96ef0ea-ac0f-47d5-bfc6-7cbf4db132c0	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2006	2010	us	ID46 (PCF7936/7961)	HY15 / لِيشي: HU134	315 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD (Smart Pro / AutoProPad)	BCM — يُفك عند فقد Pin Code وعدم توفر جهاز OBD	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
861a3aa3-70b5-49cc-a2af-8987516eb3d2	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2006	2010	gcc	ID46 (PCF7936/7961)	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
a2c6b7c6-1087-46d5-a5e3-b7e6b0bfc6e2	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2011	2014	us	ID46 / Hitag2	HY15 — بعض الفئات مفتاح ذكي (SUV/عليا)	315 MHz	obd	OBD إلزامي غالباً (Pin Code يُقرأ عبر الجهاز مباشرة من BCM)	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
ce6f8a5b-6ab9-4820-9be8-f9205416dd11	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2011	2014	gcc	ID46 / Hitag2	HY15 — بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
2502d3be-ea4d-4a67-9ef6-708cd92bd316	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2015	2019	us	Hitag2 / ID46 — مفتاح ذكي شائع	HY22 (Emergency) / لِيشي: HU134	315 MHz	obd	OBD إلزامي، بعض الفئات تحتاج تصريح أونلاين من هيونداي	Smart Key Unit + BCM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
5c00e561-e2f9-484e-9e93-2184ace743d0	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2015	2019	gcc	Hitag2 / ID46 — مفتاح ذكي شائع	HY22 (Emergency)	433 MHz	obd	OBD إلزامي، بعض الفئات تحتاج تصريح أونلاين	Smart Key Unit + BCM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
87b73b2b-d3fb-4f95-a12d-ebd6552bce3b	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2020	2024	us	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي (إلزامي تقريباً)	Smart Key Unit — الوصول المباشر نادراً ما يكون متاحاً	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
7735e5c0-a5c5-4d76-8d3b-2ec0c4609ace	2026-08-31 08:34:02.653922+00	هيونداي	سوناتا	2020	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
695349e0-7c16-49d7-b9e5-43deec100e1b	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	1998	2002	us	Texas Instruments 4C (PATS 1)	H75 / لِيشي: FO21	315 MHz	manual	يدوية بالكامل عبر دورة PATS القياسية بدون أي جهاز	غير مطلوب — النظام PATS 1 لا يحتاج EEPROM في الحالات العادية	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
ed75863c-a3d4-4ee4-98be-3ac8656175e5	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	1998	2002	gcc	Texas Instruments 4C (PATS 1)	H75 / لِيشي: FO21	315 MHz (وحدات مستوردة أمريكية غالباً)	manual	يدوية بالكامل عبر دورة PATS القياسية	غير مطلوب في الحالات العادية	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
e0920eaa-1714-497a-a542-20d051014b14	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2003	2007	us	Texas Instruments 4D-63 (PATS 3)	H84 / لِيشي: FO21	315 MHz	obd	يدوية إذا توفر مفتاحان سليمان، أو OBD (Incode/Outcode) عند فقد كل المفاتيح	وحدة PATS خلف الكلستر — يحتاج Incode من الوكالة أو جهاز متخصص عند الفقد الكامل	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
7267f7c7-7722-43b3-bc48-94681201ab93	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2003	2007	gcc	Texas Instruments 4D-63 (PATS 3)	H84 / لِيشي: FO21	315 MHz	obd	يدوية بمفتاحين سليمين، أو OBD (Incode/Outcode) عند الفقد الكامل	وحدة PATS خلف الكلستر	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
6d7edf56-8fd0-4071-83cb-918830912add	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2008	2011	us	Texas Instruments 4D-63 (PATS 4)	H84 / لِيشي: FO21	315 MHz	obd	OBD مطلوب غالباً (Smart Pro / AutoProPad) — الطريقة اليدوية محدودة الفعالية في هذا الجيل	وحدة PATS / BCM — خلف الكلستر	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
7a12f7cc-7f7f-409e-8b55-6aac1caf33ca	2026-08-31 08:34:02.653922+00	فورد	كراون فيكتوريا	2008	2011	gcc	Texas Instruments 4D-63 (PATS 4)	H84 / لِيشي: FO21	315 MHz	obd	OBD مطلوب غالباً	وحدة PATS / BCM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
8fdb9dae-52d4-47db-a032-5a77126b711e	2026-08-31 12:28:38.645175+00	تويوتا	كورولا	2007	2013	gcc	4D	toy43	433	manual			\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788189589921_1000112017.jpg	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
40d155f2-2965-4e6c-90e6-8c9a6499fa3b	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2016	2020	gcc	Toyota H-Chip (128-bit AES)	TOY44D / لِيشي: TOY44	433 MHz	obd	OBD إلزامي - Smart Pro / AutoProPad	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
eabb98f3-44c7-4245-87c1-b5138ef239cf	2026-09-01 08:03:29.022875+00	تويوتا	هايلكس	2021	2024	gcc	Toyota H-Chip / بعض الفئات مفتاح ذكي	TOY44D	433 MHz	obd	OBD + تصريح أونلاين للفئات ذات المفتاح الذكي	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
dffb1c16-054b-47bb-b054-aa162163133a	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	1998	2007	gcc	Toyota 4D-67/4D-68	TOY43/44 / لِيشي: TOY43	433 MHz	obd	يدوي بمفتاحين سليمين أحياناً، وإلا OBD	ECU / BCM حسب الفئة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
b010d9df-ad5d-4f0b-95b1-caaabb5186d5	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2008	2015	gcc	Toyota G-Chip (128-bit)	TOY44 / لِيشي: TOY44	433 MHz	obd	OBD إلزامي غالباً	BCM أسفل لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
fdaa0b7d-eedf-4eac-8c1f-90d948c5f431	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2016	2021	gcc	Toyota H-Chip / مفتاح ذكي شائع	TOY44D	433 MHz	obd	OBD + تصريح أونلاين لفئات المفتاح الذكي	Smart Key ECU / BCM	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
1ac9811d-7395-4dda-abc8-ae8b0ef04d58	2026-09-01 08:03:29.022875+00	تويوتا	لاند كروزر	2022	2024	gcc	Toyota H-Chip (AES) / مفتاح ذكي بالكامل	مفتاح ذكي - بدون شفرة تقليدية	433 MHz	obd	OBD + تصريح أونلاين من تويوتا (إلزامي تقريباً)	Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
0f8bd9c5-27aa-484b-b25f-5d3cdb7c31a8	2026-09-01 08:03:29.022875+00	نيسان	باترول	1997	2001	gcc	بدون شريحة (بعض الفئات) / أو Nissan ID46 مبكر	NI04 / لِيشي: HU46	315 MHz	manual	يدوية بالكامل - قص وبرمجة مباشرة بدون جهاز في الفئات بدون مناعة	لا يوجد EEPROM في الفئات بدون مناعة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
f7ae5bd2-632c-4cb6-ba2b-3b1fdb614e32	2026-09-01 08:03:29.022875+00	نيسان	باترول	2002	2010	gcc	Nissan ID46 (PCF7936)	NI04 / لِيشي: NI05	433 MHz	obd	OBD غالباً، يدوي أحياناً بمفتاحين سليمين	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
55b3aa7b-0eb9-4cdc-ba90-650a9c881189	2026-09-01 08:03:29.022875+00	نيسان	باترول	2010	2019	gcc	Nissan ID46 / Hitag - مفتاح ذكي شائع	مفتاح ذكي (Emergency: NI04)	433 MHz	obd	OBD إلزامي - Smart Pro / AutoProPad	BCM / Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
67bebb5a-b806-46d7-a8c6-eea9ca20d196	2026-09-01 08:03:29.022875+00	نيسان	باترول	2020	2024	gcc	Hitag AES - مفتاح ذكي بالكامل	مفتاح ذكي	433 MHz	obd	OBD + تصريح أونلاين لبعض الفئات	Smart Key ECU	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
20e92fd8-b6d1-497a-be3c-9605ed7b9859	2026-09-01 08:03:29.022875+00	نيسان	صني	2011	2016	gcc	Nissan ID46 (PCF7936)	NSN14 / لِيشي: NSN14	433 MHz	obd	OBD غالباً، يدوي أحياناً بمفتاحين سليمين	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
65ea49c5-5c3e-427a-8932-d4cee481abc0	2026-09-01 08:03:29.022875+00	نيسان	صني	2017	2024	gcc	Nissan ID46 / Hitag2	NSN14 / لِيشي: NSN14	433 MHz	obd	OBD إلزامي غالباً	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
91ad8f7e-6253-42ad-92a7-c15dcba312a7	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2012	2018	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code (SMARTRA)، وإلا OBD	BCM خلف لوحة القيادة	\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788270104611_1000112511.jpg	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
e1141967-27bd-4dce-97c2-366124597fbf	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2017	2020	gcc	Hitag2 / NCF29A1 (انتقالي)	HY15 / بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً، مفتاح ذكي يحتاج تصريح أونلاين أحياناً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
361940f1-07b4-467d-8978-d2724d7b1ee6	2026-09-01 08:03:29.022875+00	هيونداي	إلنترا	2021	2024	gcc	NCF29A1 / Hitag3 - مفتاح ذكي شائع	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي غالباً	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
24751d5b-d68a-4072-884e-855d15314400	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2010	2015	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
8b7ef6b9-63b3-428b-9f65-f214ca2da39a	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2016	2020	gcc	Hitag2 - مفتاح ذكي شائع بالفئات العليا	HY15 / مفتاح ذكي بالفئات العليا	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
8d99a077-0360-4deb-88ef-e196d337ad84	2026-09-01 08:03:29.022875+00	هيونداي	توسان	2021	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر هيونداي	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
34370653-4629-4380-8463-f1518b3a044f	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2011	2016	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code (SMARTRA)، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
3b772e99-b163-4a81-b110-270654b102e4	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2017	2021	gcc	Hitag2 - مفتاح ذكي شائع بالفئات العليا	HY15 / مفتاح ذكي بالفئات العليا	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
990248c8-06eb-4c75-8ef2-ef4ec1af9743	2026-09-01 08:03:29.022875+00	كيا	سبورتيج	2022	2024	gcc	NCF29A1 / Hitag3	مفتاح ذكي بالكامل	433 MHz	obd	OBD + Pin Code أونلاين عبر سيرفر كيا	Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
3b67443e-fc28-43e7-a8b3-98d216ea9702	2026-09-01 08:03:29.022875+00	كيا	سيراتو	2013	2018	gcc	ID46 / Hitag2	HY15 / لِيشي: HU134	433 MHz	obd	يدوي أحياناً عبر Pin Code، وإلا OBD	BCM خلف لوحة القيادة	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
35422c2b-5061-4f93-b418-224ddb4c89a4	2026-09-01 08:03:29.022875+00	كيا	سيراتو	2019	2024	gcc	Hitag2 / NCF29A1	HY15 / بعض الفئات مفتاح ذكي	433 MHz	obd	OBD إلزامي غالباً	BCM / Smart Key Unit	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
a841916d-89e8-4fea-957f-f46693b4ef8b	2026-09-01 13:39:07.451982+00	هيونداي	إلنترا	2014	2017	gcc	46		95440-1M110  /433	obd			\N	https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/1788269942223_1000112510.jpg	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
f3c3598b-d841-418f-ae24-5b46dd81712e	2026-09-02 21:54:59.791132+00	تويوتا	لاند كروزر (Land Cruiser V8 / LC300)	2016	2023	gcc	Texas Crypto 8A (Page 1: F3 / A9 / AA)	TOY48 / TOY2 / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK Dual Frequency	obd	برمجة مباشرة OBD II مع دعم محاكي Emulator في حالة All Keys Lost — الأجهزة الموصى بها: Autel MaxiIM IM608 Pro II / Key Tool Plus / Lonsdor K518ISE		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
2eace631-9b34-4581-a4a4-43d0e9885e01	2026-09-02 21:54:59.791132+00	نيسان	باترول (Patrol Y62)	2010	2023	gcc	ID46 PCF7952 / Hitag2 / AES (حسب الموديل)	NSN14 / لِيشي: Lishi NSN14 (2-in-1)	433.92 MHz FSK	obd	برمجة OBD II مع قراءة رمز BCM وحسابه إلى 20-Digit أو 4-Digit PIN — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
a5279a30-c05b-44d5-aab8-df5ffe8bc58f	2026-09-02 21:54:59.791132+00	نيسان	ألتيما (Altima)	2019	2024	gcc	Hitag AES (ID4A / NCF29A1M)	NSN14 / لِيشي: Lishi NSN14	433.92 MHz FSK (GCC Specs)	obd	عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
8434840c-8962-4804-8f33-d888597eb635	2026-09-02 21:54:59.791132+00	لكزس	LX570 / LX600	2016	2024	gcc	Texas Crypto 8A / Page 1: A9/AA/F3	TOY48 / TOY2 / لِيشي: Lishi TOY48	433.92 MHz FSK Dual	obd	عن طريق OBD II مباشرة مع خيار إضافة مفتاح ذكي أو كرت لكزس Smart Card — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / Lonsdor		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
36856840-2525-472e-83c7-2fc0c22f1d84	2026-09-02 21:54:59.791132+00	كيا	سبورتاج (Sportage)	2017	2022	gcc	Hitag3 (ID47)	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
8d55a472-2057-4347-bee4-c79c577c50ae	2026-09-02 21:54:59.791132+00	تويوتا	كامري	2012	2017	gcc	4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)	TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)	433.92 MHz ASK	obd	برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR		\N	\N		remote					\N	medium	\N	\N
ec202f86-b13f-4ffe-b695-ed393a4c85d7	2026-09-02 21:54:59.791132+00	هيونداي	إلنترا	2016	2020	gcc	ID47 Hitag3	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N		remote					\N	medium	\N	\N
f30bbb58-c435-4669-a8e0-48aebb103e43	2026-09-02 21:54:59.791132+00	هيونداي	سوناتا	2020	2024	gcc	Hitag AES / NCF29A1X (ID47)	HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)	433.92 MHz FSK	obd	برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor		\N	\N		remote					\N	medium	\N	\N
6ca3e637-32c0-469c-8503-b9992f5b1148	2026-09-02 21:54:59.791132+00	فورد	تورس	2015	2023	gcc	83ford80bits	HU101 / لِيشي: Lishi HU101 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR	جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)	\N	\N		remote					\N	medium	\N	 | تصحيح من: nasemm56@hotmail.com
24736680-121d-4582-8763-4d9997105895	2026-09-02 21:54:59.791132+00	جمس / شيفروليه	يوكن / تاهو / سييرا (Yukon / Tahoe / Sierra)	2015	2020	gcc	Hitag Pro (ID46 / ID49 GM)	HU100 (Laser Cut) / لِيشي: Lishi HU100 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق منفذ OBD II مع عد أمان تنازلي 10 - 12 دقيقة (12 Min Security Pass) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR X300	جيب البرمجة داخل مسند الذراع الأوسط / الكونسول (Key Pocket)	\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
6bd3e5e6-4c1c-46f5-9e9f-0ee3850dc14a	2026-09-02 21:54:59.791132+00	هوندا	أكورد (Accord)	2018	2023	gcc	Hitag3 (ID47 Honda)	HON66 (Laser Cut 4 Track) / لِيشي: Lishi HON66 (2-in-1)	433.92 MHz FSK	obd	برمجة مباشرة عبر OBD II بدون الحاجة لرموز أمان معقدة — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
84da66f8-3055-4595-a4de-e3341b4ed40b	2026-09-02 21:54:59.791132+00	مازدا	مازدا 6 (Mazda 6 / CX-5)	2016	2023	gcc	ID49 Hitag Pro	MAZ24R / MAZ20 / لِيشي: Lishi MAZ24 / MAZ20	433.92 MHz FSK	obd	عن طريق منفذ OBD II مباشرة بخطوتين سهلتين — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
6b3c38a3-2571-4e6e-a6ea-2fbc2f4ce02e	2026-09-02 21:54:59.791132+00	إيسوزو	ديماكس (D-Max / MUX)	2020	2024	gcc	ID46 / Hitag AES	ISU5 / HU100 / لِيشي: Lishi ISU5 / HU100	433.92 MHz	obd	عن طريق OBD II مباشرة مع رمز PIN Code الإيسوزو — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
16d601a7-d6b4-40d0-bfeb-009fc576377f	2026-09-02 21:54:59.791132+00	شأنغان	ألسفن / السفن / CS95 / Uni-K	2020	2024	gcc	Hitag3 (ID47) / Hitag AES	HU92 / HU100 / Changan Custom / لِيشي: Lishi HU92 / HU100	433.92 MHz FSK	obd	عن طريق OBD II باستخدام أجهزة متخصصة للسيارات الصينية — الأجهزة الموصى بها: Autel KM100 / OBDSTAR X300 DP Plus / Lonsdor K518		\N	\N	\N	remote	\N	\N	\N	\N	\N	medium	\N	\N
b2b2b733-d225-4054-90e0-2f97978b7386	2026-09-02 22:26:01.958576+00	تويوتا	لاند كروزر (Land Cruiser V8 / LC300)	2016	2023	gcc	Texas Crypto 8A (Page 1: F3 / A9 / AA)	TOY48 / TOY2 / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK Dual Frequency	obd	برمجة مباشرة OBD II مع دعم محاكي Emulator في حالة All Keys Lost — الأجهزة الموصى بها: Autel MaxiIM IM608 Pro II / Key Tool Plus / Lonsdor K518ISE		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
4b8722d0-2b53-4933-88b3-b9bce37442f3	2026-09-02 22:26:01.958576+00	نيسان	باترول (Patrol Y62)	2010	2023	gcc	ID46 PCF7952 / Hitag2 / AES (حسب الموديل)	NSN14 / لِيشي: Lishi NSN14 (2-in-1)	433.92 MHz FSK	obd	برمجة OBD II مع قراءة رمز BCM وحسابه إلى 20-Digit أو 4-Digit PIN — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
55a79da5-02d4-4e4f-a561-72d5f71ff1ee	2026-09-02 22:26:01.958576+00	لكزس	LX570 / LX600	2016	2024	gcc	Texas Crypto 8A / Page 1: A9/AA/F3	TOY48 / TOY2 / لِيشي: Lishi TOY48	433.92 MHz FSK Dual	obd	عن طريق OBD II مباشرة مع خيار إضافة مفتاح ذكي أو كرت لكزس Smart Card — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / Lonsdor		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
a622869d-8a5c-410c-a76d-4c9975b8b1db	2026-09-02 22:26:01.958576+00	كيا	سبورتاج (Sportage)	2017	2022	gcc	Hitag3 (ID47)	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
582c14d2-537e-41ed-928f-fb2ec7a05c6e	2026-09-02 22:26:01.958576+00	جمس / شيفروليه	يوكن / تاهو / سييرا (Yukon / Tahoe / Sierra)	2015	2020	gcc	Hitag Pro (ID46 / ID49 GM)	HU100 (Laser Cut) / لِيشي: Lishi HU100 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق منفذ OBD II مع عد أمان تنازلي 10 - 12 دقيقة (12 Min Security Pass) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / OBDSTAR X300	جيب البرمجة داخل مسند الذراع الأوسط / الكونسول (Key Pocket)	\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
ca2f2c88-a536-4870-81af-7ff69fa525c1	2026-09-02 22:26:01.958576+00	هوندا	أكورد (Accord)	2018	2023	gcc	Hitag3 (ID47 Honda)	HON66 (Laser Cut 4 Track) / لِيشي: Lishi HON66 (2-in-1)	433.92 MHz FSK	obd	برمجة مباشرة عبر OBD II بدون الحاجة لرموز أمان معقدة — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
429ed3c4-5ff1-423d-b221-cc0ee4ff2b03	2026-09-02 22:26:01.958576+00	تويوتا	كامري	2012	2017	gcc	4D67 / 72 G-Chip / 88 H-Chip (حسب سنة الصنع)	TOY43 (Flat 10 Cut) / لِيشي: Lishi TOY43AT (2-in-1)	433.92 MHz ASK	obd	برمجة الشريحة عبر OBD II + برمجة الريموت يدويًا أو عبر الجهاز — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / Xhorse VVDI Mini / OBDSTAR		\N	\N		\N					\N	medium	\N	\N
ff888159-4d1b-465e-90bf-0c01bfac5f5f	2026-09-02 22:26:01.958576+00	هيونداي	إلنترا	2016	2020	gcc	ID47 Hitag3	HY22 / لِيشي: Lishi HY22	433.92 MHz FSK	obd	منفذ OBD مع إدخال PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI / OBDSTAR		\N	\N		\N					\N	medium	\N	\N
f3dcd12b-be35-4557-8d2e-44c108a209f2	2026-09-02 22:26:01.958576+00	هيونداي	سوناتا	2020	2024	gcc	Hitag AES / NCF29A1X (ID47)	HY22 (Laser Cut 4 Track) / لِيشي: Lishi HY22 (2-in-1)	433.92 MHz FSK	obd	برمجة عن طريق منفذ OBD II مع إدخال رمز PIN Code المكون من 6 أرقام — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR X300 DP / Lonsdor		\N	\N		\N					\N	medium	\N	\N
5c7840d5-e8db-4f60-9588-ce57b75164c2	2026-09-02 22:26:01.958576+00	فورد	تورس	2015	2023	gcc	Hitag Pro / ID49 / Texas 128-Bit	HU101 / لِيشي: Lishi HU101 (2-in-1)	433.92 MHz FSK (GCC) / 315 MHz (US)	obd	عن طريق OBD II وتتطلب الانتظار لمدة 10 دقائق (Bypass Security Delay) — الأجهزة الموصى بها: Autel IM608 / KM100 / Key Tool Max Pro / FDRS / OBDSTAR	جيب البرمجة داخل الدرج الأوسط أو تحت حامل الأكواب (Key Pocket)	\N	\N		\N					\N	medium	\N	\N
6ebdb222-40fb-4607-9810-b3e2936b00e6	2026-09-02 22:26:01.958576+00	مازدا	مازدا 6 (Mazda 6 / CX-5)	2016	2023	gcc	ID49 Hitag Pro	MAZ24R / MAZ20 / لِيشي: Lishi MAZ24 / MAZ20	433.92 MHz FSK	obd	عن طريق منفذ OBD II مباشرة بخطوتين سهلتين — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
def6d4f4-7c83-4ceb-822b-a733374f9f0e	2026-09-02 22:26:01.958576+00	إيسوزو	ديماكس (D-Max / MUX)	2020	2024	gcc	ID46 / Hitag AES	ISU5 / HU100 / لِيشي: Lishi ISU5 / HU100	433.92 MHz	obd	عن طريق OBD II مباشرة مع رمز PIN Code الإيسوزو — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / OBDSTAR		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
372326bc-c180-4fc0-939b-82e2c7490a63	2026-09-02 22:26:01.958576+00	شأنغان	ألسفن / السفن / CS95 / Uni-K	2020	2024	gcc	Hitag3 (ID47) / Hitag AES	HU92 / HU100 / Changan Custom / لِيشي: Lishi HU92 / HU100	433.92 MHz FSK	obd	عن طريق OBD II باستخدام أجهزة متخصصة للسيارات الصينية — الأجهزة الموصى بها: Autel KM100 / OBDSTAR X300 DP Plus / Lonsdor K518		\N	\N	\N	\N	\N	\N	\N	\N	\N	medium	\N	\N
fce6f926-aff3-4cbc-a388-c095e5b4c283	2026-09-02 22:26:01.958576+00	نيسان	ألتيما (Altima)	2019	2024	gcc	Hitag AES (ID4A / NCF29A1M)	NSN14 / لِيشي: Lishi NSN14	433.92 MHz FSK (GCC Specs)	obd	عبر منفذ OBD II باستخدام كابل Bypass لموديلات 2020+ نيسان الشديدة الأمان — الأجهزة الموصى بها: Autel IM508/IM608 مع كابل Nissan 16+32 / OBDSTAR		\N	\N		smart					\N	medium	\N	\N
a672f727-345b-4444-b181-c54ef3787d74	2026-09-02 22:26:01.958576+00	تويوتا	كامري	2018	2024	gcc	Texas Crypto 8A (Page 1: A8 / A9 / AA)	TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK (مواصفات خليجية GCC)	obd	عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus		\N	\N		\N					\N	medium	\N	\N
bddc93bd-7823-4831-882d-9366eab3e050	2026-09-02 21:54:59.791132+00	تويوتا	كامري	2018	2024	gcc	Texas Crypto 8A (Page 1: A8 / A9 / AA)	TOY48 (Inner Cut) / لِيشي: Lishi TOY48 (2-in-1)	433.92 MHz FSK (مواصفات خليجية GCC)	obd	عن طريق منفذ OBD مباشرة باستعمال أجهزة متوافقة مع حساب 8A AKL — الأجهزة الموصى بها: Autel KM100 / Key Tool Max Pro / VVDI Key Tool Plus / OBDSTAR X300 DP Plus		\N	\N		remote					\N	medium	\N	\N
a01a7e04-08c5-4123-9599-da53989d5037	2026-09-05 02:28:30.333612+00	فورد	تورس	2013	2015	gcc	ID46 (Hitag 2)	FO38	433	manual	\N	\N	\N	\N	\N	smart	\N	\N	\N	\N	مساهمة فني: نسيم احمد	medium	\N	\N
\.


--
-- Data for Name: contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contributions (id, submitted_by, kind, target_id, payload, note, status, reviewed_by, reviewed_at, review_note, created_at, applied_car_id, prev_data) FROM stdin;
1	796b0d23-5e2b-4a05-a18d-311eb39c6c11	correction	6ca3e637-32c0-469c-8503-b9992f5b1148	{"market": "gcc", "transponder_type": "83ford80bits"}	\N	approved	796b0d23-5e2b-4a05-a18d-311eb39c6c11	2026-09-04 18:08:55.625955+00	\N	2026-09-04 17:40:02.471964+00	\N	\N
2	515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	new	\N	{"make": "فورد", "model": "تورس", "images": [{"url": "https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/contrib/1788575007796_1000113953.jpg", "kind": "remote", "caption": null}, {"url": "https://lvikmzphfunvkmpezmin.supabase.co/storage/v1/object/public/car-boards/contrib/1788575153973_1000114201.jpg", "kind": "key", "caption": null}], "market": "gcc", "year_to": "2015", "key_type": "smart", "key_blade": "FO38", "year_from": "2013", "remote_frequency": "433", "transponder_type": "ID46 (Hitag 2)"}	\N	approved	796b0d23-5e2b-4a05-a18d-311eb39c6c11	2026-09-05 02:28:30.333612+00	\N	2026-09-05 02:26:45.608889+00	\N	\N
\.


--
-- Data for Name: lishi_tools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lishi_tools (id, tool_name, blade_code, supported_cars, cut_positions, pick_direction, notes, created_at) FROM stdin;
1	Lishi TOY43AT (2-in-1)	TOY43	تويوتا كامري، أوريون، يارس، كورولا، هايلكس، برادو (2000 - 2017)	10 اسطوانات (Flat 10-Cut) / قراءة من 1 إلى 10	فتح مع اتجاه عقارب الساعة للباب الأيسر للسائق	الأسطوانات 1 و 2 تكون عادة مسؤولة عن فتح الشنطة، بينما 3-10 تفتح السلف والأبواب.	2026-09-02 23:46:15.688185+00
2	Lishi TOY48 (2-in-1)	TOY48 / TOY2	تويوتا لاندكروزر، كامري بصمة، لكزس LX570, ES350, LS460	4 مسارات داخلية (4-Track Inner Cut) / 8 اسطوانات	التقاط الاسطوانات حسب النظام المزدوج (A & B)	تأكد من عدم الضغط بقوة على الريشة لتجنب كسر سناد القفل الداخلي لسلندر لكزس.	2026-09-02 23:46:15.688185+00
3	Lishi HY22 (2-in-1)	HY22	هيونداي سوناتا، إلنترا، توسان، أزيرا / كيا سبورتاج، أوبتيما، سيراتو	4 مسارات ليزر (4-Track Laser Cut) / 8 أو 12 اسطوانة	الفتح باتجاه مقدمة السيارة	شائعة جداً في السيارات الكورية. انتبه للفرق بين موديلات 8 كليكس و 12 كليكس.	2026-09-02 23:46:15.688185+00
4	Lishi NSN14 (2-in-1)	NSN14	نيسان باترول Y62، ألتيما، صني، مكسيما، نافارا / إنفينيتي QX80	10 اسطوانات مقسمة على الجانبين (5 على كل جانب)	عكس اتجاه عقارب الساعة للأبواب الخليجية	يجب الضغط الخفيف جداً عند فك قفل BCM نيسان لمنع التعليق.	2026-09-02 23:46:15.688185+00
5	Lishi HU100 (2-in-1)	HU100	جمس يوكن، سييرا / شيفروليه تاهو، كابريس، ماليبو / أوبل	مسارين ليزر (2-Track Laser Cut) / 8 أو 10 اسطوانات	التقاط المسارات العلوي والسفلي بالتناوب	تستخدم لسيارات جنرال موتورز حديثة من 2010 إلى 2023.	2026-09-02 23:46:15.688185+00
6	Lishi HON66 (2-in-1)	HON66	هوندا أكورد، سيفيك، CR-V، أوديسي / أكيورا	4 مسارات ليزر / قراءة اسطوانات المقابض	باتجاه الخلف لفتح الباب	سلاسل هوندا تتطلب تنظيف السلندر بالبخاخ المنظف قبل التقاط الأسطوانات.	2026-09-02 23:46:15.688185+00
7	Lishi HU101 (2-in-1)	HU101	فورد تورس، إكسبلورر، F-150، فلكس / فولفو	10 اسطوانات مسار خارجي	مع اتجاه العقارب للباب الأمامي	تحديد عمق Cut 1 إلى 4 بدقة على ماكينات القص الكهروميكانيكية.	2026-09-02 23:46:15.688185+00
8	Lishi HU66 (2-in-1)	HU66	فولكس واجن، أودي، بورش، سيات، سكودا	8 اسطوانات مسارين ليزر	التقاط متعامد	الموديلات الأوروبية وتتطلب محول فك سريع.	2026-09-02 23:46:15.688185+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (id, role, status, display_name, workshop_name, city, license_ref_hash, mfa_required, locked_until, created_at, updated_at, workshop_id, workshop_role) FROM stdin;
796b0d23-5e2b-4a05-a18d-311eb39c6c11	super_admin	verified	\N	\N	\N	\N	t	\N	2026-09-02 23:51:39.757992+00	2026-09-02 23:51:39.757992+00	\N	\N
515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	locksmith	verified	نسيم احمد	المفالح الذهبي	بحره	e250b2131edaf42597bc933daf0e359be0926981f854bd8ec8c7b00f7c8db744	f	\N	2026-09-03 20:15:34.372103+00	2026-09-04 11:47:23.361059+00	\N	\N
\.


--
-- Data for Name: rate_limit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_limit_events (id, actor_key, action, created_at) FROM stdin;
1	a:e59bc992ccc99da1d538e7713bea98fcadeced22c78447d93e45d3ea72cd11aa	search_cars	2026-09-03 00:40:46.518578+00
2	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:42:50.215426+00
3	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:43:00.523169+00
4	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:44:12.088123+00
5	a:8c9bf3fbb9276591bd8525d32c75a51dcaff1e148373a8929350f971ff0baa98	search_cars	2026-09-03 00:46:41.243946+00
6	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-03 01:16:21.627246+00
7	a:98164a5aed7b82d5c6f5104e2d2e0a8c87b5d879c8858e68cb0f7db1f691f9b7	search_cars	2026-09-03 04:20:40.04203+00
8	a:84d25c6a3a258fcd7467e8cea0676c3bf67f2b2cb288a8eae9ad7191594d5b43	search_cars	2026-09-03 19:18:16.301082+00
9	a:84d25c6a3a258fcd7467e8cea0676c3bf67f2b2cb288a8eae9ad7191594d5b43	search_cars	2026-09-03 19:18:21.180083+00
10	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	sync_all_cars	2026-09-03 19:49:36.448658+00
11	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_text	2026-09-04 04:53:22.086073+00
12	a:84d25c6a3a258fcd7467e8cea0676c3bf67f2b2cb288a8eae9ad7191594d5b43	search_cars	2026-09-04 04:57:39.635656+00
13	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	sync_all_cars	2026-09-04 06:17:15.621748+00
14	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_text	2026-09-04 10:59:28.782134+00
15	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_text	2026-09-04 10:59:47.453973+00
16	a:a4015802aa2ca699508548cd483cf705ec72854b1be751f3b0dfb85bb4ecf3e6	search_cars	2026-09-04 14:03:26.167566+00
17	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_text	2026-09-04 14:13:01.443441+00
18	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_text	2026-09-04 15:57:05.156209+00
19	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 17:36:19.401208+00
20	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 17:36:22.913356+00
21	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	submit_contribution	2026-09-04 17:40:02.471964+00
22	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 18:10:20.27052+00
23	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 18:41:02.938848+00
24	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 20:12:42.222958+00
25	u:796b0d23-5e2b-4a05-a18d-311eb39c6c11	search_cars	2026-09-04 20:12:45.613815+00
26	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_text	2026-09-05 01:50:10.38741+00
27	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_text	2026-09-05 01:50:25.21657+00
28	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_cars	2026-09-05 02:04:22.23476+00
29	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	submit_contribution	2026-09-05 02:26:45.608889+00
30	a:75f99b8bccf7169b9c248a271e18bab75a0c5e3a964d2c9a6350145e4f435870	search_cars	2026-09-05 02:54:29.056942+00
31	a:75f99b8bccf7169b9c248a271e18bab75a0c5e3a964d2c9a6350145e4f435870	search_cars	2026-09-05 02:54:36.76504+00
32	u:515ed2c9-b248-4b54-b8fa-0a6ee5bf3143	search_cars	2026-09-05 02:57:22.960409+00
\.


--
-- Data for Name: search_misses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_misses (id, query_norm, hits, created_at) FROM stdin;
1	كامري	14	2026-09-04 15:57:05.156209+00
2	كامري	14	2026-09-05 01:50:10.38741+00
3	كامري	14	2026-09-05 01:50:25.21657+00
\.


--
-- Data for Name: work_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_log (id, technician_id, car_ref, job_type, vin_fingerprint, notes, created_at) FROM stdin;
\.


--
-- Data for Name: workshops; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workshops (id, name, city, owner_id, seat_limit, status, created_at) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 22, true);


--
-- Name: car_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.car_images_id_seq', 5, true);


--
-- Name: contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contributions_id_seq', 2, true);


--
-- Name: lishi_tools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lishi_tools_id_seq', 8, true);


--
-- Name: rate_limit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rate_limit_events_id_seq', 32, true);


--
-- Name: search_misses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.search_misses_id_seq', 3, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: car_images car_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.car_images
    ADD CONSTRAINT car_images_pkey PRIMARY KEY (id);


--
-- Name: cars_key_data cars_key_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cars_key_data
    ADD CONSTRAINT cars_key_data_pkey PRIMARY KEY (id);


--
-- Name: contributions contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT contributions_pkey PRIMARY KEY (id);


--
-- Name: lishi_tools lishi_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lishi_tools
    ADD CONSTRAINT lishi_tools_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_events rate_limit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limit_events
    ADD CONSTRAINT rate_limit_events_pkey PRIMARY KEY (id);


--
-- Name: search_misses search_misses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_misses
    ADD CONSTRAINT search_misses_pkey PRIMARY KEY (id);


--
-- Name: work_log work_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_log
    ADD CONSTRAINT work_log_pkey PRIMARY KEY (id);


--
-- Name: workshops workshops_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workshops
    ADD CONSTRAINT workshops_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor ON public.audit_log USING btree (actor_id, created_at DESC);


--
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_car_images_car; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_car_images_car ON public.car_images USING btree (car_id, sort_order);


--
-- Name: idx_cars_confidence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_confidence ON public.cars_key_data USING btree (confidence);


--
-- Name: idx_cars_key_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_key_type ON public.cars_key_data USING btree (key_type);


--
-- Name: idx_cars_make; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make ON public.cars_key_data USING btree (make);


--
-- Name: idx_cars_make_base; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make_base ON public.cars_key_data USING btree (make_base);


--
-- Name: idx_cars_make_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make_model ON public.cars_key_data USING btree (make, model);


--
-- Name: idx_cars_make_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make_norm ON public.cars_key_data USING btree (make_norm);


--
-- Name: idx_cars_make_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_make_trgm ON public.cars_key_data USING gin (make_norm public.gin_trgm_ops);


--
-- Name: idx_cars_model_base; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_model_base ON public.cars_key_data USING btree (model_base);


--
-- Name: idx_cars_model_norm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_model_norm ON public.cars_key_data USING btree (model_norm);


--
-- Name: idx_cars_model_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cars_model_trgm ON public.cars_key_data USING gin (model_norm public.gin_trgm_ops);


--
-- Name: idx_contrib_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contrib_by ON public.contributions USING btree (submitted_by, created_at DESC);


--
-- Name: idx_contrib_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contrib_status ON public.contributions USING btree (status, created_at DESC);


--
-- Name: idx_misses_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_misses_date ON public.search_misses USING btree (created_at DESC);


--
-- Name: idx_misses_query; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_misses_query ON public.search_misses USING btree (query_norm);


--
-- Name: idx_profiles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_role ON public.profiles USING btree (role);


--
-- Name: idx_profiles_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_status ON public.profiles USING btree (status);


--
-- Name: idx_profiles_workshop; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_workshop ON public.profiles USING btree (workshop_id);


--
-- Name: idx_rate_limit_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_limit_lookup ON public.rate_limit_events USING btree (actor_key, action, created_at DESC);


--
-- Name: idx_work_log_tech; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_work_log_tech ON public.work_log USING btree (technician_id, created_at DESC);


--
-- Name: idx_workshops_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workshops_owner ON public.workshops USING btree (owner_id);


--
-- Name: cars_key_data trg_audit_cars; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_cars AFTER INSERT OR DELETE OR UPDATE ON public.cars_key_data FOR EACH ROW EXECUTE FUNCTION public.record_audit();


--
-- Name: profiles trg_audit_profiles; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_profiles AFTER INSERT OR DELETE OR UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.record_audit();


--
-- Name: profiles trg_profiles_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_guard BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.guard_profile_privileges();


--
-- Name: profiles trg_profiles_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: contributions contributions_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT contributions_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_workshop_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_workshop_id_fkey FOREIGN KEY (workshop_id) REFERENCES public.workshops(id) ON DELETE SET NULL;


--
-- Name: work_log work_log_technician_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_log
    ADD CONSTRAINT work_log_technician_id_fkey FOREIGN KEY (technician_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: workshops workshops_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workshops
    ADD CONSTRAINT workshops_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_admin_read ON public.audit_log FOR SELECT TO authenticated USING (public.is_super_admin());


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: car_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.car_images ENABLE ROW LEVEL SECURITY;

--
-- Name: cars_key_data cars_admin_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cars_admin_write ON public.cars_key_data TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: cars_key_data; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cars_key_data ENABLE ROW LEVEL SECURITY;

--
-- Name: cars_key_data cars_locksmith_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cars_locksmith_read ON public.cars_key_data FOR SELECT TO authenticated USING (public.is_verified_locksmith());


--
-- Name: contributions contrib_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contrib_admin_read ON public.contributions FOR SELECT TO authenticated USING (public.is_super_admin());


--
-- Name: contributions contrib_own_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contrib_own_read ON public.contributions FOR SELECT TO authenticated USING ((submitted_by = ( SELECT auth.uid() AS uid)));


--
-- Name: contributions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contributions ENABLE ROW LEVEL SECURITY;

--
-- Name: lishi_tools lishi_admin_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lishi_admin_write ON public.lishi_tools TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: lishi_tools lishi_locksmith_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lishi_locksmith_read ON public.lishi_tools FOR SELECT TO authenticated USING (public.is_verified_locksmith());


--
-- Name: lishi_tools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lishi_tools ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_admin_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_admin_all ON public.profiles TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: profiles profiles_select_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_admin ON public.profiles FOR SELECT TO authenticated USING (public.is_super_admin());


--
-- Name: profiles profiles_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_own ON public.profiles FOR SELECT TO authenticated USING ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: profiles profiles_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE TO authenticated USING ((id = ( SELECT auth.uid() AS uid))) WITH CHECK ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: rate_limit_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rate_limit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: search_misses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.search_misses ENABLE ROW LEVEL SECURITY;

--
-- Name: work_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_log ENABLE ROW LEVEL SECURITY;

--
-- Name: work_log work_log_own_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_delete ON public.work_log FOR DELETE TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- Name: work_log work_log_own_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_insert ON public.work_log FOR INSERT TO authenticated WITH CHECK (((technician_id = ( SELECT auth.uid() AS uid)) AND public.is_verified_locksmith()));


--
-- Name: work_log work_log_own_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_select ON public.work_log FOR SELECT TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- Name: work_log work_log_own_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_log_own_update ON public.work_log FOR UPDATE TO authenticated USING ((technician_id = ( SELECT auth.uid() AS uid))) WITH CHECK ((technician_id = ( SELECT auth.uid() AS uid)));


--
-- Name: workshops; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workshops ENABLE ROW LEVEL SECURITY;

--
-- Name: workshops ws_admin_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ws_admin_all ON public.workshops TO authenticated USING ((public.is_super_admin() AND public.has_mfa())) WITH CHECK ((public.is_super_admin() AND public.has_mfa()));


--
-- Name: workshops ws_member_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ws_member_read ON public.workshops FOR SELECT TO authenticated USING ((id = ( SELECT p.workshop_id
   FROM public.profiles p
  WHERE (p.id = ( SELECT auth.uid() AS uid)))));


--
-- PostgreSQL database dump complete
--

\unrestrict sV5mbeanczt1tM4uE0tp6A6BCWCpbhClbs9SR8of5ZwkK6Dtumivl3Mbd1DMjQC

